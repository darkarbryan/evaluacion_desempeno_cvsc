<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<title>Ingreso a evaluacion</title>
</head>
<body class="bg-black">
	
	<?php

	ob_start();
	session_name('ingreso_usuario');
	session_start();

	if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==1 ){
		echo '<script>window.location.href="Administracion/dashboard/menuAdministrador.php";</script>';
	}if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==2 ){
		echo '<script>window.location.href="Evaluacion/Evaluacion.php";</script>';
	}else{

		?>

		<div class="container" style="justify-content: center; display: flex; align-items: center; min-height: 80vh; margin-left: 20%; margin-right: 20%;">

			<form action="PHP/controlIngreso.php" method="POST" class="form-inline">	

				<div class="row align-items-center">

					<div class="col col-lg-6 col-sm-6">
						<div class="row">
							<div class="col form-group">
								<img src="Img/usuario.png" class="mt-3" ><br>
								<label>Identificacion</label>								
								<input type="text" name="usuario" placeholder="Ingrese su identificacion" class="form-control mt-3">								
							</div>
						</div>

						<div class="row">
							<div class="col form-group">
								<img src="Img/contrasena.png" class="mt-3"><br>
								<label>Contraseña</label>
								<input type="password" name="clave" required minlength="8" class="form-control mt-3">
							</div>
						</div>					
					</div>

					<div class="row">
						<div class="col col-lg-6 col-sm-6 pt-5">
							<input type="submit" name="submitIngreso" value="Ingresar a la plataforma" class="btn btn-success">
						</div>
					</div>	

					<div class="row">
						<div class="col-lg-6 col-sm-6 pt-4">
							<a href="Restablecimiento/restablecerContrasena.php" style="text-decoration:none">
								<h4>
										<span class="text-primary">
										Restablecer contraseña
										</span>
								</h3>							
							</a>
						</div>
					</div>			

				</div>					

			</form>	

		</div>

		<!-- PIE DE PAGINA -->
		<footer class="card-footer text-muted" align="center" style="bottom: 0; position: absolute; width: 100%">
			<h3>Colviseg de caribe</h3>           
		</footer>	

		<?php
	}
	?>
</body>
</html>