<?php

print_r(PDO::getAvailableDrivers());

?>