<?php
/*
require "PerfilConexion.php";

$Perfil2 = new PerfilConexion2();

$servidor = $Perfil2->getServerName();
$DBname = $Perfil2->getDataBaseName();
$usuario = $Perfil2->getUser();
$pass = $Perfil2->getPass();


try{

    $conexionServ = new PDO($driver.':host='.$servidor.';dbname='.$DBname, $usuario, $clave);
    
    
}catch(Exception $e){

    echo 'Error al tratar de realizar la conexion al servidor.<br>'.$e;
    //echo '<script>window.location.href="javascript:history.back();"</script>';
	exit;
}
*/
?>