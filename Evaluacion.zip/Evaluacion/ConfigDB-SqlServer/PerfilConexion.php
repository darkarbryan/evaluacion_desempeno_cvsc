<?php
/* 
class PerfilConexion2{

	private $usr = 'bryan.valderrama';
	private $pss = 'Macs100607';
	private $servName = '181.49.3.226';// ip privada" 192.168.0.13"; 
	private $DBName = 'prueba_temporal';
	private $driverConexion = 'dblib';

	public function getUser(){
		return $this->usr;
	}

	public function getPass(){
		return $this->pss;
	}

	public function getServerName(){
		return $this->servName;
	}

	public function getDataBaseName(){
		return $this->DBName;
	}
	
	public function getDriverConexion(){
	    return $this->driverConexion;
	}

}
*/
?>