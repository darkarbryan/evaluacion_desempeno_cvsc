<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include_once 'datosCorreoEmisor.php';
include_once '../ConfigDB/config.php'; //archivo de conexion a la BD

ob_start();
session_name('ingreso_usuario');
session_start();

//verificar que se acceda desde el formulario
if( isset($_POST['submitRecupera']) ){		

	$correoRestablecer = $_POST['correoRestablece'];	
	$_SESSION['correo'] = $correoRestablecer;
	$codigo = rand(1000,9999);			
	
	$perfilEmisor = new Perfil();

	$queryGuardarCodigo = "INSERT INTO passwords (correo, codigo) values('$correoRestablecer',$codigo)";

	$ejecucion = mysqli_query($conexion, $queryGuardarCodigo);
	
	if($ejecucion){

		try{			

			require("../PHP/PHPMailer/src/PHPMailer.php");
			require("../PHP/PHPMailer/src/Exception.php");
			require("../PHP/PHPMailer/src/SMTP.php");			

			$mail = new PHPMailer(true);

			try{

			//$mail->SMTPDebug = 2;
				$mail->isSMTP(); 					
				$mail->Host       = 'smtp.office365.com'; 
				$mail->SMTPAuth   = true;
				$mail->Username   = $perfilEmisor->getUser();
				$mail->Password   = $perfilEmisor->getPass();
				$mail->SMTPSecure = 'tls';			       
				$mail->Port       = 587;
				$mail->CharSet = 'UTF-8';				

				$mensaje = '
				<html>
				<head>
				<title>Restablecimiento</title>
				<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
				</head>
				<body>	
				<div style="text-align: center;">
				<p>
				<h2>Restablecimiento de contraseña</h2>
				</p>
				<p>
				<h3>Codigo de restablecimiento</h3>
				<h3>'.$codigo.'</h3>
				</p>
				<p>
				<small>En caso de que usted no haya hecho esta solicitud,ignore este mensaje.
				</small>
				</p>			
				</div>
				</body>
				</html>
				';

				$mail->setFrom($perfilEmisor->getUser(), 'Restablecimiento de contraseña');    
				$mail->addAddress($correoRestablecer); 

				$mail->isHTML(true);                                  
				$mail->Subject = 'Envio de codigo para restablecer la contraseña';
				$mail->Body    = $mensaje;
				$mail->AltBody = 'Envio de codigo para restablecer la contraseña';

				if($mail->send()){					

					?>				
					<!DOCTYPE html>
					<html>
					<head>
						<title>Confirmacion</title>
						<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>
					</head>
					<body>

						<script>
							Swal.fire('Codigo enviado!','Verifique en la bandeja de entrada o en correo no deseado de su cuenta','success').then((result)=>{	
								window.location.href="ingresoCodigo.php"; });
						</script>

					</body>
					</html>				
					<?php

				}else{

					?>				
					<!DOCTYPE html>
					<html>
					<head>
						<title>Confirmacion</title>
						<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>
					</head>
					<body>

						<script>
							Swal.fire({icon: 'error',title: 'Oops...',text: "Hubo un error al enviar el correo." }).then((result)=>{
								window.location.href="restablecerContrasena.php";
							});
						</script>

					</body>
					</html>				
					<?php
					
				}

			}catch(Exception $e1){
				echo "Error en la preparacion del correo:  {$mail->ErrorInfo}";
			};

		}catch(Exception $e2){ echo "Error al incluir las librerias necesarias para funciones PHPMailer{$e2}";
	};

}else{

	?>				
	<!DOCTYPE html>
	<html>
	<head>
		<title>Confirmacion</title>
		<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>
	</head>
	<body>

		<script>
			Swal.fire({icon: 'error',title: 'Oops...',text: "Hubo un problema de comunicacion con la base de datos. Intente nuevamente." }).then((result)=>{
				window.location.href="restablecerContrasena.php";
			});
		</script>

	</body>
	</html>				
	<?php			

}

}

?>

