<?php
	
	/**
	 * datos de correo de emisor para envio
	 */
	class Perfil
	{
		//correo y clave de correo empresarial en bluehost
		private $nombreUsuario 	= "aprendizit@cvsc.com.co";
		private $passUsuario 		= "Macs100607**";				
		
		public function getUser(){
			return $this->nombreUsuario;
		}

		public function getPass(){
			return $this->passUsuario;
		}


	}

?>