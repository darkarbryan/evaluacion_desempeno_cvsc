<!DOCTYPE html>
<html>
<head>
	<title>Restablecer la contraseña de acceso</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>
	<?php

	ob_start();
	session_name('ingreso_usuario');
	session_start();

	if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==1 ){
		echo '<script>window.location.href="../Administracion/menuAdministrador.php";</script>';

	}if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==2 ){
		echo '<script>window.location.href="../Evaluacion/Evaluacion.php";</script>';

	}else{
		?>

			<header>
				<div class="container" align="center">
				<div class="row align-items-center">
					<div class="col col-lg-3 col-sm-2">
						<img src="../Img/logo_colviseg.png"><br>				
					</div>
					<div class="col col-lg-6 col-sm-8 ">
						<h1 class="text-primary">Sistema de Gestión</h1>
						<h2 style="color:#1c1c1c">Evaluacion de Desempeño</h2>
						<h3 class="text-secondary">Modulo restablecimiento de contraseña</h3>
					</div>
					<div class="col col-lg-3 col-sm-2">
						<img src="../Img/usuario_activo.png"><br><br>						
						<a href="../index.php"><button type="button" class="btn btn-danger">Volver al inicio</button></a>
					</div>
				</div>
			</div>
			</header>	

			<div class="container" align="center" style="padding-bottom: 5%; padding-left: 22%; padding-top: 10%;">

				<form action="envioCorreo.php" method="POST">
					<div class="row" >
						<div class="col col-lg-7 col-sm-7">
							<label class="text-primary h5">Ingrese el correo a restablecer la contraseña</label>
							<input type="mail" name="correoRestablece" id="correoRestablece" required class="form-control text-secondary h5">
						</div>
					</div>				

					<div class="row">
						<div class="col col-lg-7 col-sm-7">
							<input type="submit" id="submitRecupera" name="submitRecupera" value="Restablecer contraseña" class="btn btn-success mt-5">						
						</div>
					</div>
				</form>

			</div>

			<!-- PIE DE PAGINA -->
			<footer class="card-footer text-muted" align="center" style="bottom: 0; position: absolute; width: 100%">
					<h3>Colviseg de caribe</h3>
			</footer>	

		<?php
	}

	?>	
</body>
</html>