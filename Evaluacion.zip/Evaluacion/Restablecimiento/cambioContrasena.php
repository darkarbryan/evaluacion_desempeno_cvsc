<!DOCTYPE html>
<html>
<head>
	<title>Cambio de contraseña</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>
</head>
<body>
	<?php

	include_once '../ConfigDB/config.php';

	ob_start();
	session_name('ingreso_usuario');
	session_start();

	if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==1 ){
		echo '<script>window.location.href="../Administracion/menuAdministrador.php";</script>';

	}else if( isset($_SESSION['rol_usuario']) && $_SESSION['rol_usuario']==2 ){
		echo '<script>window.location.href="../Evaluacion/Evaluacion.php";</script>';

	}else{

		if( isset($_POST['contra1']) ){

			$passwordRecibido = $_POST['contra1'];
			$correoRecibido = $_POST['correoEnvio'];

			$queryUpdateContraseña = "UPDATE usuario SET contrasena='$passwordRecibido' WHERE correo='$correoRecibido'; ";

			$ejecucion = mysqli_query($conexion, $queryUpdateContraseña);

			if($ejecucion){

				session_unset();
				session_destroy();
				mysqli_close($conexion);

				?>
					<script>
						Swal.fire('Operacion exitosa!','La contraseña fue cambiada exitosamente.','success').then((result)=>{		
								window.location.href="../index.php";	});
					</script>
				<?php

			}else{

				?>
					<script>
						Swal.fire({icon: 'error',title: 'Oops...',text: "Hubo un error al realizar el cambio de contraseña en la base de datos. Verifique que se haya realizado el cambio o intente nuevamente cambiarla." }).then((result)=>{window.location.href="../index.php";});
					</script>
				<?php

			}

		}else{
			echo '<script>window.location.href="restablecerContrasena.php";</script>';
		}

	}

	?>
</body>
</html>