<!DOCTYPE html>
<html>
<head>
	<title>Verificacion de codigo</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>
<body>

	<?php

	include_once '../ConfigDB/config.php';

	//Verficar que se haya accedido desde la pagina de ingresoCpdigo.php

	if( isset($_POST['submitCodigo']) ){

		$codigoRecibido	= (int)$_POST['codigoReestablece'];
		$correoRecibido = $_POST['correoEnvio'];

		$queryCodigoExistente = "SELECT * FROM passwords WHERE correo='$correoRecibido' AND codigo=$codigoRecibido; ";

		$ejecucion = mysqli_query($conexion, $queryCodigoExistente);

		if(mysqli_num_rows($ejecucion) > 0){

			$fila = mysqli_fetch_row($ejecucion);

			$fechaDB = $fila[3];

			date_default_timezone_set('America/Bogota');
			$fecha_actual = date('Y-m-d h:i:s a', time());

			$segundosDiferencia = strtotime($fecha_actual) - strtotime($fechaDB);			

			if($segundosDiferencia > 1800){ //media hora

				?>
				<script>
					Swal.fire({icon: 'error',title: 'Oops...',text: "Se excedio el tiempo limite para e ingreso del codigo de restablecimiento." }).then((result)=>{window.location.href="restablecerContrasena.php";});
				</script>
				<?php

			}else{

				?>

				<header>
					<div class="container" align="center">
						<div class="row align-items-center">
							<div class="col col-lg-3 col-sm-2">
								<img src="../Img/logo_colviseg.png"><br>				
							</div>
							<div class="col col-lg-6 col-sm-8 ">
								<h1 class="text-primary">Sistema de Gestión</h1>
								<h2 style="color:#1c1c1c">Evaluacion de Desempeño</h2>
								<h3 class="text-secondary">Modulo restablecimiento de contraseña</h3>
							</div>
							<div class="col col-lg-3 col-sm-2">
								<img src="../Img/usuario_activo.png"><br><br>						
								<a href="../index.php"><button type="button" class="btn btn-danger">Volver al inicio</button></a>
							</div>
						</div>
					</div>
				</header>	

				<script>
					function comprobarIgualdad(){

						let clave1 = document.getElementById("contra1").value;
						let clave2 = document.getElementById("contra2").value;

						if(clave1 == clave2){
							
							document.formCambioContra.submit();

						}else{

							Swal.fire({icon: 'error',title: 'Oops...',text: "Las contraseñas no coinciden." });
						}

					}
				</script>

				<form action="cambioContrasena.php" method="POST" name="formCambioContra">

					<div class="container" align="center" style="padding-bottom: 5%; padding-left: 22%; padding-top: 5%;">

						<div class="row" >
							<div class="col col-lg-7 col-sm-7">
								<label class="text-primary h5">Ingrese la nueva contraseña</label>						
								<input type="password" name="contra1" id="contra1" required class="form-control text-secondary h5" minlength="8">

								<label class="text-primary h5 pt-5">Confirme la nueva contraseña</label>						
								<input type="password" name="contra2" id="contra2" required class="form-control text-secondary h5" minlength="8">

								<input type="mail" name="correoEnvio" id="correoEnvio" hidden value=<?php echo $correoRecibido; ?> >
							</div>
						</div>				

						<div class="row">
							<div class="col col-lg-7 col-sm-7">
								<input type="button" id="submitContrasena" name="submitContrasena" value="Cambiar contraseña" class="btn btn-success mt-5" onclick="comprobarIgualdad();">						
							</div>
						</div>

					</div>

				</form>			

				<!-- PIE DE PAGINA -->
				<footer class="card-footer text-muted" align="center" style="bottom: 0; position: absolute; width: 100%">
					<h3>Colviseg de caribe</h3>
				</footer>	

				<?php			

			}

		}else{

			?>
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: "El codigo ingresado no es valido. Intente de nuevo." }).then((result)=>{window.location.href="ingresoCodigo.php";});
			</script>
			<?php			

		}

	}else{
		echo '<script>window.location.href="restablecerContrasena.php";</script>';
	}

	?>

</body>
</html>