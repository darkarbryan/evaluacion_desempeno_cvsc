<?php

	class PerfilConexion{

		private $usr = "cvsccomc_avantro";
		private $pss = "Macs100607";
		private $servName = "localhost";//"www.cvsc.com.co";//"localhost";
		private $DBName = "cvsccomc_evaluaciondesempeno";

		public function getUser(){
			return $this->usr;
		}

		public function getPass(){
			return $this->pss;
		}

		public function getServerName(){
			return $this->servName;
		}

		public function getDataBaseName(){
			return $this->DBName;
		}

	}

?>