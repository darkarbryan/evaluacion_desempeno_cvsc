<?php

ob_start();
session_name('ingreso_usuario');
session_start();

if( isset($_SESSION['nom_usuario']) ){
	$nombre_login = $_SESSION['nom_usuario'];
}else{
	$nombre_login = "No existe";
}

if( isset($_SESSION['rol_usuario']) ){
	$rol_login = $_SESSION['rol_usuario'];
}else{
	$rol_login = -1;
}

if( isset($_SESSION['nom_usuario']) && $_SESSION['rol_usuario']==1 ){

	include 'arriba.php';
	?>

	<!-- Begin Page Content -->

	<div class="container-fluid">		

		<!-- Cabecera contenido -->
		<div class="d-sm-flex align-items-center justify-content-between mb-4">
			<h1 class="h3 mb-0 text-gray-800">Dashboard</h1>					
		</div>

		<!-- Contenedor de tarjetas de estados de evaluacion-->
		<div class="row"> 

			<!-- tarjeta % de evaluaciones realizadas -->
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-info shadow h-100 py-2">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="text-xs font-weight-bold text-info text-uppercase mb-1">Evaluaciones realizadas
								</div>
								<div class="row no-gutters align-items-center">
									<div class="col-auto">
										<div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
											<label id="cantidadRealizada"></label>
										</div>
									</div>
									<div class="col">
										<div class="progress progress-sm mr-2">
											<div id="progress-bar-div" class="progress-bar bg-info" role="progressbar"
											style="width: 50%" aria-valuenow="100" aria-valuemin="0"
											aria-valuemax="100"></div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-auto">
								<i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!-- Personal faltante por evaluar -->
			<div class="col-xl-3 col-md-6 mb-4">
				<div class="card border-left-warning shadow h-100 py-2">
					<div class="card-body">
						<div class="row no-gutters align-items-center">
							<div class="col mr-2">
								<div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
								Faltantes por evaluar</div>
								<div class="h5 mb-0 font-weight-bold text-gray-800">
									<label id="faltantesEvaluacion"></label>
								</div>
							</div>
							<div class="col-auto">
								<i class="fas fa-tasks fa-2x text-gray-300"></i>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Content Row -->

		<div class="row">

			<!-- Area Chart -->
			<div class="col-xl-8 col-lg-7">
				<div class="card shadow mb-4">
					<!-- Card Header - Dropdown -->
					<div
					class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
					<h6 class="m-0 font-weight-bold text-primary">Promedio de puntuacion por categorias de evaluacion</h6>
					
		</div>
		<!-- Card Body -->
		<div class="card-body">

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Relaciones interpersonales</label>		
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ1"></div>
				</div>
			</div>

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Comunicaciones</label>					
				</div>			
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ2"></div>
				</div>
			</div>

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Actitud de servicio</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ3"></div>
				</div>
			</div>			

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Solucion de conflictos</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ4"></div>
				</div>
			</div>

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Calidad y compromiso con el trabajo</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ5"></div>
				</div>
			</div>

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Seguridad y salud en el trabajo</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ6"></div>
				</div>
			</div>			

			<div class="row">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary">Conocimientos en seguridad fisica</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="categ7"></div>
				</div>
			</div>			

			<div class="row pt-5">
				<div class="col col-xl-9 col-md-9 col-lg-9">
					<label class="text-primary h4">Promedio general para el periodo actual</label>
				</div>
				<div class="col col-xl-3 col-md-3 col-lg-3">
					<div id="promedioFinal"></div>
				</div>
			</div>		
			
		</div>
	</div>
</div>

<!-- Pie Chart -->
<div class="col-xl-4 col-lg-5">
	<div class="card shadow mb-4">
		<!-- Card Header - Dropdown -->
		<div
		class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
		<h6 class="m-0 font-weight-bold text-primary">Cantidad de preguntas diligenciadas por area</h6>		
</div>
<!-- Card Body -->
<div class="card-body">
	<div class="chart-pie pt-4 pb-2">
		<canvas id="myPieChart"></canvas>
	</div>
	<div class="mt-4 text-center small">
		<span class="mr-2">
			<i class="fas fa-circle text-primary"></i> Vigilantes
		</span>
		<span class="mr-2">
			<i class="fas fa-circle text-success"></i> Supervisores
		</span>
		<span class="mr-2">
			<i class="fas fa-circle text-info"></i> OMT
		</span>
		<span class="mr-2">
			<i class="fas fa-circle text-warning"></i> Escoltas
		</span>
		<span class="mr-2">
			<i class="fas fa-circle text-danger"></i> Administrativos
		</span>
	</div>
</div>
</div>
</div>
</div>		

	<!-- PROMEDIOS DE AREAS CARGO DE EVALUACION TARJETA -->
	<div class="row">
		
		<!-- Area Chart -->
		<div class="col-xl-8 col-lg-7">

			<div class="card shadow mb-4">
				<!-- Card Header - Dropdown -->
				<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
				<h6 class="m-0 font-weight-bold text-primary">Promedio de puntuacion por cargo</h6>					
				</div>

				<!-- Card Body -->
			<div class="card-body">

				<div class="row">
					<div class="col col-xl-7 col-md-8 col-lg-7">
						<label class="text-primary">Vigilantes</label>		
					</div>
					<div class="col col-xl-5 col-md-4 col-lg-5">
						<div id="areaCargo1"></div>
					</div>
				</div>

				<div class="row">
					<div class="col col-xl-7 col-md-8 col-lg-7">
						<label class="text-primary">Supervisores</label>		
					</div>
					<div class="col col-xl-5 col-md-4 col-lg-5">
						<div id="areaCargo2"></div>
					</div>
				</div>

				<div class="row">
					<div class="col col-xl-7 col-md-8 col-lg-7">
						<label class="text-primary">OMT</label>		
					</div>
					<div class="col col-xl-5 col-md-4 col-lg-5">
						<div id="areaCargo3"></div>
					</div>
				</div>

				<div class="row">
					<div class="col col-xl-7 col-md-8 col-lg-7">
						<label class="text-primary">Escoltas</label>		
					</div>
					<div class="col col-xl-5 col-md-4 col-lg-5">
						<div id="areaCargo4"></div>
					</div>
				</div>

				<div class="row pt-5">
					<div class="col col-xl-7 col-md-8 col-lg-7">
						<label class="text-primary h4">Promedio general</label>		
					</div>
					<div class="col col-xl-5 col-md-4 col-lg-5">
						<div id="areaCargoGeneral"></div>
					</div>
				</div>				

			</div>

			</div>			

		</div>

	</div>
</div>

<!-- /.container-fluid -->		
<?php
include 'abajo.php';

}else{

	include 'redireccionLogin.php';

}
?>