<?php

include_once 'ConsultaCategPreg.php';

ob_start();
session_name('ingreso_usuario');
session_start();

if( isset($_SESSION['nom_usuario']) ){
	$nombre_login = $_SESSION['nom_usuario'];
}else{
	$nombre_login = "No existe";
}

if( isset($_SESSION['rol_usuario']) ){
	$rol_login = $_SESSION['rol_usuario'];
}else{
	$rol_login = -1;
}
if(isset($nombre_login) && $rol_login==1){

	include 'arriba.php';

	?>		

	<form class="form-group" method="POST" action="Insercion.php" id="formCrearCategoria">
		<div class="container pt-5 pb-5" >

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Pregunta a registrar</label>						
				</div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6"><input type="text" name="pregunta" id="pregunta" required placeholder="Ingrese la pregunta que desea crear" class="form-control">
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Observaciones de la pregunta</label>
				</div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<textarea name="observacion" id="observacion" required placeholder="Indique las observaciones que desee hacer con respecto a la pregunta" class="form-control"></textarea>
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Orden de la pregunta</label>
				</div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<input type="number" name="orden" id="orden" required placeholder="Ingrese el orden de la pregunta a crear" class="form-control" min="1" value="1" readonly="true">
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Categoria perteneciente</label>						
				</div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6">			
					<select name="tipoCategoria" id="tipoCategoria" required class="form-control">
						<option value="">Seleccione una</option>
						<?php

						foreach ($ArrayCategorias as $key => $value) {
							echo "<option value=".$ArrayCategoriasId[$key].">".$ArrayCategorias[$key]."";
						}

						?>						
					</select>
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Estado de la pregunta</label>
				</div>
				<div class="col">
					<div class="row">
						<div class="col">
							<label class="text-secondary">Indique el estado en el que desea crear la pregunta, activo o inactivo.</label>
						</div>							
					</div>
					<div class="row">
						<div class="col">
							<label class="checkbox-inline"><input class="m-1" type="radio" name="estado" id="activo" value="1" checked="true">Activo		
							</label>
							<label class="checkbox-inline"><input class="m-1" type="radio" name="estado" id="inactivo" value="0">Inactivo		
							</label>
						</div>
					</div>
				</div>
			</div>

			<div class="row pt-5 pb-5" align="center">
				<div class="col col-md-16 ">
					<input type="submit" name="submitPregunta" id="submitPregunta" value="Guardar Pregunta" class="btn btn-success">
					<input type="reset" name="Reestablecer" value="Reestablecer campos" class="btn btn-secondary">
				</div>									
			</div>

		</div>
	</form>

	<?php

	include 'abajo.php';

}else{
	?>

	<script>
		Swal.fire({icon: 'error',title: 'Oops...',text: 'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
			window.location.href="../index.php";
		});
	</script>

	<?php
}
?>
</body>
</html>