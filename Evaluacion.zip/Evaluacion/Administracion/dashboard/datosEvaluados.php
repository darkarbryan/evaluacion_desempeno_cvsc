  <?php

  ob_start();
  session_name('ingreso_usuario');
  session_start();

  if( isset($_SESSION['nom_usuario']) ){
    $nombre_login = $_SESSION['nom_usuario'];
  }else{
    $nombre_login = "No existe";
  }

  if( isset($_SESSION['rol_usuario']) ){
    $rol_login = $_SESSION['rol_usuario'];
  }else{
    $rol_login = -1;
  }

  if( isset($_SESSION['nom_usuario']) && $_SESSION['rol_usuario']==1){

    include 'arriba.php';

    ?>
    <!-- CONTENIDO DE LA PAGINA -->
    
    <script src="js/appEvaluados.js"></script>                   

    <div class="container-fluid">
      <div id="contenedorTablas"> 
        <!-- CONTENIDO DONDE VA LA TABLA DESDE app.js -->
      </div> 
    </div> 

    <?php

    include 'abajo.php';

  }else{
    ?>

    <!-- redireccion a login con javascript -->
    <script>
      Swal.fire({icon: 'error',title: 'Oops...',text:'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
        window.location.href="../../index.php";
      });
    </script>   

    <?php
  }
  ?>
</body>
</html>