<!DOCTYPE html>
<html>
<head>
	<title>Registro en proceso...</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>	
</head>
<body>
	<?php
	include '../../ConfigDB/config.php';

	if( isset($_POST['submitCategoria']) ){

		$nombreCategoria = $_POST['nomCategoria'];
		$descrCategoria = $_POST['descrCategoria'];
		$ordenCategoria = (int)$_POST['ordCategoria'];

		if( isset($_POST['administrativo']) ){
			$chkAdministrativo = 1;
		}else{		
			$chkAdministrativo = 0;
		}

		if( isset($_POST['vigilante']) ){
			$chkVigilante = 1;
		}else{
			$chkVigilante = 0;
		}

		if( isset($_POST['supervisor']) ){
			$chkSupervisor = 1;
		}else{
			$chkSupervisor = 0;
		}

		if( isset($_POST['OMT']) ){
			$chkOMT = 1;
		}else{
			$chkOMT = 0;
		}

		if( isset($_POST['escolta']) ){
			$chkEscolta = 1;
		}else{
			$chkEscolta = 0;
		}

	//SE HACE LA INSERCION SIN INCLUIR EL CAMPO AUTOINCREMENTABLE DE LA TABLA.
		$cadenaInsercionCategoria = "INSERT INTO categoria (nombre,descripcion,orden,administrativo,vigilancia,escolta,supervision,omt) VALUES ('$nombreCategoria','$descrCategoria',$ordenCategoria,$chkAdministrativo,$chkVigilante,$chkEscolta,$chkSupervisor,$chkOMT)";

		if( mysqli_query($conexion,$cadenaInsercionCategoria) ){
			?>

			<script>
				Swal.fire('Todo en orden.','Evaluacion registrada exitosamente!','success').then((result)=>{
					window.location.href="formCrearCategoria.php";							
				});
			</script>

			<?php
			mysqli_close($conexion);	

		}else{		
			?>
			
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: 'La categoria no fue guardada.' }).then((result)=>{
					window.location.href="formCrearCategoria.php";
				});
			</script>

			<?php
		}

	}else if( isset($_POST['submitPregunta']) ){

		$pregunta = $_POST['pregunta'];
		$observaciones = $_POST['observacion'];
		$orden = (int)$_POST['orden'];
		$tipoCategoria = $_POST['tipoCategoria'];
		$estado = $_POST['estado'];

		$cadenaInsercionPregunta = "INSERT INTO pregunta (pregunta,observacion,orden,categoria,activo) VALUES ('$pregunta','$observaciones',$orden,$tipoCategoria,$estado)";

		if( mysqli_query($conexion,$cadenaInsercionPregunta) ){
			?>

				<script>
					Swal.fire('Todo en orden.','Se ha registrado la pregunta!','success').then((result)=>{
						window.location.href="formCrearPregunta.php";							
					});
				</script>

			<?php
			mysqli_close($conexion);		

		}else{
			?>
			
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: 'La pregunta no fue guardada.' }).then((result)=>{
					window.location.href="formCrearCategoria.php";
				});
			</script>

			<?php	
		}

	}else if( isset($_POST['submitUsuario']) ){

		$idEvaluador = $_POST['id_usuario'];
		$nombreEvaluador = $_POST['nombre_usuario'];
		$correoEvaluador = $_POST['correo_usuario'];
		$rolEvaluador = (int) $_POST['rol_usuario'];
		$rolOasisEvaluador = 0; //esta por defecto para implementacion a futuro
		$passwordEvaluador = $_POST['pass_usuario'] ;		
		$estadoUsuarioEvaluador = (int) $_POST['activo_usuario']; 			

		$cadenaRegistroUsuario = "INSERT INTO usuario (identificacion, nombre_completo, correo, rol_evaluacion, rol_oasis, contrasena, activo) VALUES($idEvaluador, '$nombreEvaluador', '$correoEvaluador', $rolEvaluador, $rolOasisEvaluador, '$passwordEvaluador', $estadoUsuarioEvaluador)";

		if( mysqli_query($conexion,$cadenaRegistroUsuario) ){
			?>

				<script>
					Swal.fire('Todo en orden.','Se ha registrado al usuario','success').then((result)=>{
						window.location.href="formCrearEvaluador.php";							
					});
				</script>

			<?php
			mysqli_close($conexion);		

		}else{
			?>
			
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: 'El usuario no fue creado.' }).then((result)=>{
					window.location.href="formCrearEvaluador.php";
				});
			</script>

			<?php	
		}

	}else{
		//devuelve a la pagina anteriormente visitada.
		echo '<script>window.location.href="javascript:history.back();"</script>';
	}
	?>
</body>
</html>