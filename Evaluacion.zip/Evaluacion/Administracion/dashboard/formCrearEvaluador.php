<?php

ob_start();
session_name('ingreso_usuario');
session_start();

if( isset($_SESSION['nom_usuario']) ){
	$nombre_login = $_SESSION['nom_usuario'];
}else{
	$nombre_login = "No existe";
}

if( isset($_SESSION['rol_usuario']) ){
	$rol_login = $_SESSION['rol_usuario'];
}else{
	$rol_login = -1;
}
if(isset($nombre_login) && $rol_login==1){

	include 'arriba.php';

	?>

	<form method="POST" action="Insercion.php" class="form-group">

		<div class="container pt-5 pb-5" >

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Identificacion del usuario</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<input class="form-control" type="text" name="id_usuario" id="id_usuario" required placeholder="Ingrese la identificacion" onkeypress='return soloNumeros(event);'>
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Nombre completo del usuario</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<input class="form-control" type="text" name="nombre_usuario" id="nombre_usuario" required placeholder="Ingrese el nombre completo">
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Correo electronico del usuario</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<input class="form-control" type="email" name="correo_usuario" id="correo_usuario" pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{1,5}" required placeholder="Ingrese el correo electronico">
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Rol a asignar</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<select class="form-control" required name="rol_usuario" id="rol_usuario">
						<option value="">Seleccione una</option>
						<option value="1">Administrador</option>
						<option value="2">Evaluador</option>
					</select>
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Rol proveniente de Oasis</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<select class="form-control" disabled="true" name="rol_usuario_oasis" id="rol_usuario_oasis">
						<option value="0">0 (Por defecto)</option>							
					</select>
				</div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Contraseña del usuario</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					<input class="form-control" type="password" name="pass_usuario" id="pass_usuario" required placeholder="Ingrese la contrasena a crear" minlength="8" maxlength="32">
				</div>
			</div>

			<div class="row md-12 pt-4">

				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6">
					<label class="text-primary h5">Estado del usuario</label>
				</div>

				<div class="col col-md-8 col-sm-6 col-lg-8 col-xs-6">
					
					<div class="container-radioButton" style="float: left; padding-left: 20px;">
						<input class="form-check-input" type="radio" name="activo_usuario" required value="1" id="activo">
						<label class="text-secondary h6 form-check-label" for="activo">Activo</label>
					</div>

					<div class="container-radioButton" style="float: left; padding-left: 50px;">
						<input class="form-check-input" type="radio" name="activo_usuario" required value="0" id="inactivo">
						<label class="text-secondary h6 form-check-label" for="inactivo">Inactivo</label>
					</div>											

				</div>

			</div>

			<div class="row pt-5 pb-5" align="center">
				<div class="col col-md-16 ">
					<input type="submit" name="submitUsuario" id="submitUsuario" value="Registrar usuario" class="btn btn-success">
					<input type="reset" name="Reestablecer" value="Reestablecer campos" class="btn btn-secondary">
				</div>									
			</div>

		</div>

	</form> 

	<?php

	include 'abajo.php';

}else{
	?>

	<script>
		Swal.fire({icon: 'error',title: 'Oops...',text: 'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
			window.location.href="../index.php";
		});
	</script>

	<?php
}	