<!DOCTYPE html>
<html>
<head>
	<title>Sesion no valida</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script> 
</head>
<body>

	<!-- redireccion a login con javascript -->
	<script>
		Swal.fire({icon: 'error',title: 'Oops...',text:'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
			window.location.href="../../index.php";
		});
	</script>

</body>
</html>