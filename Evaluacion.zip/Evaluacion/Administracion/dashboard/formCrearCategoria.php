<?php

ob_start();
session_name('ingreso_usuario');
session_start();

if( isset($_SESSION['nom_usuario']) ){
	$nombre_login = $_SESSION['nom_usuario'];
}else{
	$nombre_login = "No existe";
}

if( isset($_SESSION['rol_usuario']) ){
	$rol_login = $_SESSION['rol_usuario'];
}else{
	$rol_login = -1;
}
if( isset($nombre_login) && $rol_login==1 ){
	
	include 'arriba.php';

	?>		

	<form class="form-group" method="POST" action="Insercion.php" id="formCrearCategoria">
		<div class="container pt-5 pb-5">

			<div class="row md-12 pt-4">
				<div class="col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Nombre de la categoria</label></div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6"><input type="text" name="nomCategoria" id="nomCategoria" required placeholder="Ingrese el nombre correspondiente a la categoria " class="form-control"></div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Descripcion de la categoria</label></div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6"><input type="text" name="descrCategoria" id="descrCategoria" placeholder="Ingrese la descripcion de esta categoria" class="form-control" required></div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Orden de la categoria</label></div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6"><input type="number" name="ordCategoria" id="ordCategoria" placeholder="Ingrese el orden correspondiente a la categoria " class="form-control" min="1" value="1" readonly="true"></div>
			</div>

			<div class="row md-12 pt-4">
				<div class="col-md-4 col-sm-6 col-lg-4 col-xs-6"><label class="text-primary h5">Formularios</label></div>
				<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6" align="left">

					<div class="row">
						<div class="col">
							<label class="checkbox-inline ">
								<input class="m-1" type="checkbox" name="administrativo" id="administrativo" value="1">Administrativo
							</label>
							<label class="checkbox-inline ">
								<input class="m-1" type="checkbox" name="vigilante" id="vigilante" value="1">Vigilante
							</label>
							<label class="checkbox-inline ">
								<input class="m-1" type="checkbox" name="supervisor" id="supervisor" value="1">Supervisor
							</label>										
						</div>									
					</div>

					<div class="row">
						<div class="col">
							<label class="checkbox-inline">
								<input class="m-1" type="checkbox" name="OMT" id="OMT" value="1">OMT (Operador de medios tecnologicos)
							</label>
							<label class="checkbox-inline ">
								<input class="m-1" type="checkbox" name="escolta" id="escolta" value="1">Escolta
							</label>										
						</div>
					</div>							

				</div>
			</div>

			<div class="row pt-5 pb-5" align="center">
				<div class="col col-md-16 ">
					<input type="submit" name="submitCategoria" id="submitCategoria" value="Guardar Categoria" class="btn btn-success"></input>
					<input type="reset" name="Reestablecer" value="Reestablecer campos" class="btn btn-secondary">
				</div>									
			</div>

		</div>
	</form>	
	<?php

	include 'abajo.php';

		//se trata de acceder sin haber iniciado sesion. se redirige al index (log in).
}else{
	?>
	
	<script>
		Swal.fire({icon: 'error',title: 'Oops...',text: 'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
			window.location.href="../index.php";
		});
	</script>

	<?php		
}
