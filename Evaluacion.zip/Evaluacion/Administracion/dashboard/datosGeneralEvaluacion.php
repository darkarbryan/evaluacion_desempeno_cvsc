  <?php

  ob_start();
  session_name('ingreso_usuario');
  session_start();

  if( isset($_SESSION['nom_usuario']) ){
    $nombre_login = $_SESSION['nom_usuario'];
  }else{
    $nombre_login = "No existe";
  }

  if( isset($_SESSION['rol_usuario']) ){
    $rol_login = $_SESSION['rol_usuario'];
  }else{
    $rol_login = -1;
  }

  if( isset($_SESSION['nom_usuario']) && $_SESSION['rol_usuario']==1){

    include 'arriba.php';

    ?>
    <!-- CONTENIDO DE LA PAGINA -->
    
    <script src="js/appEvaluacionGeneral.js"></script>

    <div class="container-fluid">

      <div style="padding-left: 20px;">       

        <form method="POST" action="informacion.php" target="_blank">
          
          <input type="number" name="opc" id="opc" value="8" hidden="true">

          <button id="btnGenerarEXCELGeneral" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Descargar reporte (EXCEL)
       </button>

        </form>
      
      </div>  

      <div id="contenedorTablaGeneral"> 
        <!-- CONTENIDO DONDE VA LA TABLA DESDE app.js -->
      </div> 

    </div> 

    <?php

    include 'abajo.php';

  }else{
    ?>

    <!-- redireccion a login con javascript -->
    <script>
      Swal.fire({icon: 'error',title: 'Oops...',text:'No ha iniciado sesion o su rol no esta en el nivel adminitido.' }).then((result)=>{
        window.location.href="../../index.php";
      });
    </script>   

    <?php
  }
  ?>
</body>
</html>