$(document).ready(function(){
	
	let opc = 2;

	$.ajax({

		url:'informacion.php',
		type:'POST',
		data:{ opc },
		success: function(response){

			respuestaServ2 = JSON.parse(response);

			let template = `<h3 class="text-primary pb-5" align="center">Informacion de evaluados</h3>`;
			template += `<table id="tablaDatos" class="display">`;
			template += `<thead>`;
			template += `<tr>`;				
			template += `<th>Identificacion</th>`;
			template += `<th>Nombres y apellidos</th>`;
			template += `<th>Cargo</th>`;
			template += `<th>Sede ubicacion</th>`;
			template += `<th>Periodo evaluacion</th>`;
			template += `<th>Operaciones</th>`;
			template += `</tr>`;
			template += `</thead>`;

			template += `<tbody>`;

			respuestaServ2.forEach(resp=>{


				template += `<tr>`;										
				template += `<td>${resp.identificacion}</td>`;
				template += `<td>${resp.nombre}</td>`;
				template += `<td>${resp.cargo}</td>`;
				template += `<td>${resp.ubicacion}</td>`;
				template += `<td>${resp.periodo}</td>`;
				template += `<td>`;	
				template += `<span title="Ver evaluacion">`;
						template += `<a href="resultadosEvaluacion.php?idEvaluado=${resp.identificacion}">`; //ruta de redireccion a la pagina para mostrar la evaluacion					
						template += `<button type="button" class="btn btn-primary">`;	
						template += `<i class="fas fa-search"></i>`;						
						template += `</button>`;
						template += `</a>`;
						template += `</span>`;						
						template += `</td>`;	
						template += `</tr>`;

					});

			template += `</tbody>`;
			template += `</table>`;

			$('#contenedorTablas').html(template);
			$('#tablaDatos').DataTable();

		}

	});
});