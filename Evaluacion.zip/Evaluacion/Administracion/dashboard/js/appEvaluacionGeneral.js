$(document).ready(function(){

	$(document).on('click', '#btnGenerarEXCELGeneral', function(e) {

        //e.preventDefault();
        //let opc = 8;

	 	swal.fire({

        	icon: 'info',
        	title: 'Generando informacion',
        	text: 'El informe se estara generando en un tiempo promedio de 2 hasta maximo 15 minutos, dependiendo de la cantidad de evaluados hasta el momento. No debe cerrar la pestaña abierta.',
        	showConfirmButton: false,
        	timerProgressBar: true,
        	timer: 900000 // es ms (mili-segundos) (15 minutos)

    	});

		/*
		$.ajax({

			async:true,	
			url:'informacion.php',
			type:'POST',
			data:{ opc },
			dataType: 'html',
			success: function(response){

				console.log(response);
				swal.fire({

                	icon: 'success',
                	title: 'Reporte generado',
                	showConfirmButton: false,
                	timerProgressBar: true,
                	timer: 3200 // es ms (mili-segundos)

           		});

           		var opResult = JSON.parse(data);
                var $a=$("<a>");
                    $a.attr("href",opResult.data);
                      
                    $("body").append($a);
                    $a.attr("download","hola.xlsx");
                    $a[0].click();
                    $a.remove();

			},		
			error: function(jqXHR, textStatus, errorThrown) {
		 
				swal.fire({
        			icon: 'error',
        			title: 'Se presento un problema al generar el reporte excel',
        			showConfirmButton: false,
        			timerProgressBar: true,
        			timer: 1300 // es ms (mili-segundos)
    			});

			}

		});
		*/

    });
});