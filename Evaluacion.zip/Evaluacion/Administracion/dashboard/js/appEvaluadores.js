$(document).ready(function(){	

		let opc = 1;

		$.ajax({

			url:'informacion.php',
			type:'POST',
			data:{ opc },
			success: function(response){

				respuestaServ = JSON.parse(response);

				let template = `<h3 class="text-primary pb-5" align="center">Informacion de evaluadores</h3>`;
				template += `<table id="tablaDatos" class="display">`;
				template += `<thead>`;
				template += `<tr>`;
				template += `<th>Identificacion</th>`;
				template += `<th>Nombres y apellidos</th>`;
				template += `<th>Cargo</th>`;
				template += `<th>Sede ubicacion</th>`;				
				template += `</tr>`;
				template += `</thead>`;

				template += `<tbody>`;
				
				respuestaServ.forEach(resp=>{				

					template += `<tr>`;
					template += `<td>${resp.identificacion}</td>`;
					template += `<td>${resp.nombre}</td>`;
					template += `<td>${resp.cargo}</td>`;
					template += `<td>${resp.ubicacion}</td>`;
					template += `</tr>`;

				});

				template += `</tbody>`;
				template += `</table>`;

				$('#contenedorTablas').html(template);
				$('#tablaDatos').DataTable();

			}

		});	

});