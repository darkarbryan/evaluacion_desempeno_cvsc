$(document).ready(function(){

opc = 5;

	$.ajax({

		url:'informacion.php',
		type:'POST',
		data:{ opc },
		success: function(response){

			respuestaServ = JSON.parse(response);

			var cantVigilantes;
			var cantSupervisores;
			var cantOmt;
			var cantEscoltas;
			var cantAdministrativos;			
				
			cantVigilantes = respuestaServ['cantidadVigilantes'];
			cantSupervisores = respuestaServ['cantidadSupervisores'];
			cantOmt = respuestaServ['cantidadOmt'];
			cantEscoltas = respuestaServ['cantidadEscoltas'];								
			cantAdministrativos = respuestaServ['cantidadAdministrativos'];						

			$('#cantVigilantes').html(cantVigilantes);
			$('#cantSupervisores').html(cantSupervisores); 
			$('#cantOmt').html(cantOmt);
			$('#cantEscoltas').html(cantEscoltas);
			$('#cantAdministrativos').html(cantAdministrativos);

			$('#cantVigilantes').attr("value", cantVigilantes);
			$('#cantSupervisores').attr("value", cantSupervisores);
			$('#cantOmt').attr("value", cantOmt);
			$('#cantEscoltas').attr("value", cantEscoltas);
			$('#cantAdministrativos').attr("value", cantAdministrativos);

		}

	});

});	