$(document).ready(function() {

    $(document).on('click', '#btnGenerarPDF', function(e) {
        e.preventDefault();

        var useWidth = document.getElementById("resultadoEvaluacion").style.width;
        var useHeight = document.getElementById("resultadoEvaluacion").style.height;
        var idReporte = document.getElementById("idEvaluado").value;

        html2canvas($("#resultadoEvaluacion"), {

            onrendered: function(canvas) {

                var imgData = canvas.toDataURL('image/png');
                var imgWidth = 210;
                var pageHeight = 320;//295;
                var imgHeight = ((canvas.height * imgWidth / canvas.width) + 20);
                var heightLeft = imgHeight;
                var doc = new jsPDF('p', 'mm');
                var position = 0;

                doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;

                while (heightLeft >= 0) {
                    position = heightLeft - imgHeight;
                    doc.addPage();
                    doc.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                    heightLeft -= pageHeight;
                }

                swal.fire("OK", "Generando reporte...", "info").then(result => {
                    doc.save('Evaluacion de ' + idReporte + '.pdf');
                });

            }

        });

        return false;
    });

    $(document).on('click', '#btnGenerarEXCEL', function(e) {

        e.preventDefault();
        swal.fire("Oops...", "Funcion no implementada aun.", "error");

    });

});