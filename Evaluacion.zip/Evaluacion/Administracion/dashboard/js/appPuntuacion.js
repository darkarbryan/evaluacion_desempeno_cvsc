$(document).ready(function() {

    let opc = 3;
    let idEvaluado = $('#idEvaluado').val();

    swal.fire({
        icon: 'info',
        type: 'info',
        title: 'Generando informacion',
        showConfirmButton: false,
        timerProgressBar: true,
        timer: 1300 // es ms (mili-segundos)
    });

    $.ajax({

        url: 'informacion.php',
        type: 'POST',
        data: { opc, idEvaluado },
        success: function(response) {

            respuestaServ = JSON.parse(response);

            let template = ``;

            let nombrePregunta = "";
            let puntuacionPregunta = "";
            let idEvaluado = "";
            let idEvaluador = "";
            let nombreEvaluador = "";
            let nombreEvaluado = "";
            let cargoEvaluador = "";
            let cargoEvaluado = "";
            let fechaIngresoEvaluado = "";
            let fechaEvaluacion = "";
            let idEvaluadorExamen = "";

            respuestaServ.forEach(resp => {

                if (resp.idEvaluado) {

                    fechaEvaluacion = resp.fechaEvaluacion;
                    fechaIngresoEvaluado = resp.fechaIngresoEvaluado;
                    idEvaluador = resp.idEvaluador;
                    idEvaluado = resp.idEvaluado;
                    nombreEvaluador = resp.nombreEvaluador;
                    nombreEvaluado = resp.nombreEvaluado;
                    cargoEvaluador = resp.cargoEvaluador;
                    cargoEvaluado = resp.cargoEvaluado;



                    //BLOQUE CABACERA DE LA CATEGORIA//
                    template += `<hr>`;
                    template += `<div class="container mt-3">`;
                    template += `<div class="row">`;

                    template += `<div class="col-md-6 col-sm-12 col-lg-6 col-xs-12">`;
                    template += `<div class="row">`;
                    template += `<div class="col-md-6 col-sm-6 col-lg-6 col-xs-6">`;
                    template += `<h5 class="text-primary">Fecha evaluacion</h5>`;
                    template += `<h5 class="text-primary">Id evaluador</h5>`;
                    template += `<h5 class="text-primary">Nombre evaluador</h5>`;
                    template += `<h5 class="text-primary">Cargo evaluador</h5>`;
                    template += `</div>`;
                    template += `<div class="col-md-6 col-sm-6 col-lg-6 col-xs-6">`;
                    template += `<h6 class="text-secondary">${fechaEvaluacion}</h6>`;
                    template += `<h6 class="text-secondary">${idEvaluador}</h6>`;
                    template += `<h6 class="text-secondary">${nombreEvaluador}</h6>`;
                    template += `<h6 class="text-secondary">${cargoEvaluador}</h6>`;
                    template += `</div>`;
                    template += `</div>`;
                    template += `</div>`;

                    template += `<div class="col-md-6 col-sm-12 col-lg-6 col-xs-12">`;
                    template += `<div class="row">`;
                    template += `<div class="col-md-6 col-sm-6 col-lg-6 col-xs-6">`;
                    template += `<h5 class="text-primary">Fecha ingreso</h5>`;
                    template += `<h5 class="text-primary">Id evaluado</h5>`;
                    template += `<h5 class="text-primary">Nombre evaluado</h5>`;
                    template += `<h5 class="text-primary">Cargo evaluado</h5>`;
                    template += `</div>`;
                    template += `<div class="col-md-6 col-sm-6 col-lg-6 col-xs-6">`;
                    template += `<h6 class="text-secondary">${fechaIngresoEvaluado}</h6>`;
                    template += `<h6 class="text-secondary">${idEvaluado}</h6>`;
                    template += `<h6 class="text-secondary">${nombreEvaluado}</h6>`;
                    template += `<h6 class="text-secondary">${cargoEvaluado}</h6>`;
                    template += `</div>`;
                    template += `</div>`;
                    template += `</div>`;

                    template += `</div>`;
                    template += `</div>`;
                    template += `<hr>`;
                    //FIN BLOQUE CABECERA DE CATEGORIA



                }

                if (resp.nombrePregunta != undefined && resp.puntuacion != undefined && resp.idEvaluadorExamen) {

                    nombrePregunta = resp.nombrePregunta;
                    puntuacionPregunta = resp.puntuacion;
                    idEvaluadorExamen = resp.idEvaluadorExamen;

                    //if (idEvaluador == idEvaluadorExamen) {

                        template += `<div class="container mt-3">`;
                        template += `<div class="row">`;
                        template += `<div class="col-md-10 col-sm-8 col-lg-10 col-xs-8">`;
                        template += `<h6>${nombrePregunta}</h6>`;
                        template += `</div>`;
                        template += `<div class="col-md-2 col-sm-4 col-lg-2 col-xs-4">`;

                        switch (puntuacionPregunta) {

                            case '1':
                                template += `<h6 class="form-control text txt-alert">${puntuacionPregunta} (Bajo)</h6>`;
                                break;

                            case '2':
                                template += `<h6 class="form-control">${puntuacionPregunta} (Basico)</h6>`;
                                break;

                            case '3':
                                template += `<h6 class="form-control">${puntuacionPregunta} (Medio)</h6>`;
                                break;

                            case '4':
                                template += `<h6 class="form-control">${puntuacionPregunta} (Alto)</h6>`;
                                break;

                            case '5':
                                template += `<h6 class="form-control text text-primary">${puntuacionPregunta} (Excelente)</h6>`;
                                break;

                        }

                        template += `</div>`;
                        template += `</div>`;
                        template += `</div>`;

                    //}
                }

            });

            template += `<div id="elementH"></div>`;

            swal.fire({
                icon: 'success',
                type: 'success',
                title: 'Reporte generado',
                showConfirmButton: false,
                timerProgressBar: true,
                timer: 800 // es ms (mili-segundos)
            }).then(result => {
                $('#resultadoEvaluacion').html(template);
            });

        }

    });


});