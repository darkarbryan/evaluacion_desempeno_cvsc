$(document).ready(function(){

	let opc = 4;

	$.ajax({

		url:'informacion.php',
		type:'POST',
		data:{ opc },
		success: function(response){

			respuestaServ = JSON.parse(response);

			let cantidadRealizada;
			let cantidadTotal;

			respuestaServ.forEach(resp=>{

				cantidadRealizada = parseInt(resp.cantidadRealizada, 10);
				cantidadTotal = parseInt(resp.cantidadTotal, 10);

			});
			
			let cantidadRealizadaPorc = ((cantidadRealizada*100)/cantidadTotal);
			let cantidadRealizadaPorcRedondeado = cantidadRealizadaPorc.toFixed(1);
			let etiquetaPorcentaje = cantidadRealizadaPorcRedondeado+"%";
			let faltantesEvaluacion = cantidadTotal - cantidadRealizada;

			$('#progress-bar-div').attr("style", "width:"+cantidadRealizadaPorcRedondeado+"%;");
			$('#cantidadRealizada').html(etiquetaPorcentaje);
			$('#faltantesEvaluacion').html(faltantesEvaluacion); 

		}

	});	

});