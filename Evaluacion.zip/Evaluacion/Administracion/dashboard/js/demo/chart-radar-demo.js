$(document).ready(function () {

	var promAreaCargo1;
	var promAreaCargo2;
	var promAreaCargo3;
	var promAreaCargo4;
	var promedioGeneralAreaCargo;

	opc = 7;

	$.ajax({

		async: false, //necesario
		url: 'informacion.php',
		dataType: 'html',//necesario
		type: 'POST',
		data: { opc },
		success: function (response) {

			respuestaServ = JSON.parse(response);
			let cant = 4;


			if (respuestaServ[0] !== undefined) {
				promAreaCargo1 = parseFloat(respuestaServ[0].promedioArea);
			} else {
				cant -= 1;
				promAreaCargo1 = 0.00;
			}

			if (respuestaServ[1] !== undefined) {
				promAreaCargo2 = parseFloat(respuestaServ[1].promedioArea);
			} else {
				cant -= 1;
				promAreaCargo2 = 0.00;
			}

			if (respuestaServ[2] !== undefined) {
				promAreaCargo3 = parseFloat(respuestaServ[2].promedioArea);
			} else {
				cant -= 1;
				promAreaCargo3 = 0.00;
			}

			if (respuestaServ[3] !== undefined) {
				promAreaCargo4 = parseFloat(respuestaServ[3].promedioArea);
			} else {
				cant -= 1;
				promAreaCargo4 = 0.00;
			}

			promedioGeneralAreaCargo = promAreaCargo1 + promAreaCargo2 + promAreaCargo3 + promAreaCargo4;

			if (cant <= 0) {
				promedioGeneralAreaCargo = 0.00;
			} else {
				promedioGeneralAreaCargo /= cant; //cantidad de areas de cargo.
				// serian 5 incluyendo a administrativos peor no es el caso
			}
		}

	});

	// Set new default font family and font color to mimic Bootstrap's default styling
	Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
	Chart.defaults.global.defaultFontColor = '#858796';

	// Pie Chart Example
	var ctx = document.getElementById("myRadarChart");

	const data = {
		labels: [
			'Viglantes',
			'Supervisores',
			'OMT',
			'Escoltas'
		],
		datasets: [{
			label: 'My First Dataset',
			data: [promAreaCargo1, promAreaCargo2, promAreaCargo3, promAreaCargo4],
			fill: true,
			backgroundColor: 'rgba(255, 99, 132, 0.2)',
			borderColor: 'rgb(255, 99, 132)',
			pointBackgroundColor: 'rgb(255, 99, 132)',
			pointBorderColor: '#fff',
			pointHoverBackgroundColor: '#fff',
			pointHoverBorderColor: 'rgb(255, 99, 132)'
		}]
	};

	var myRadarChart = new Chart(ctx, {

		type: 'radar',
		data: data,
		options: {
			elements: {
				line: {
					borderWidth: 3
				}
			}
		},

	});

});