var promCateg1;
var promCateg2;
var promCateg3;
var promCateg4;
var promCateg5;
var promCateg6;
var promCateg7;
var PromedioGeneral;

opc = 6;

$.ajax({

  async: false, //necesario
  url: 'informacion.php',
  dataType: 'html',//necesario
  type: 'POST',
  data: { opc },
  success: function (response) {

    respuestaServ = JSON.parse(response);
    let cant = 7;


    if (respuestaServ[0] !== undefined) {
      promCateg1 = parseFloat(respuestaServ[0].promedioPorCategoria1);
    } else {
      cant -= 1;
      promCateg1 = 0.00;
    }

    if (respuestaServ[1] !== undefined) {
      promCateg2 = parseFloat(respuestaServ[1].promedioPorCategoria2);
    } else {
      cant -= 1;
      promCateg2 = 0.00;
    }

    if (respuestaServ[2] !== undefined) {
      promCateg3 = parseFloat(respuestaServ[2].promedioPorCategoria3);
    } else {
      cant -= 1;
      promCateg3 = 0.00;
    }

    if (respuestaServ[3] !== undefined) {
      promCateg4 = parseFloat(respuestaServ[3].promedioPorCategoria4);
    } else {
      cant -= 1;
      promCateg4 = 0.00;
    }

    if (respuestaServ[4] !== undefined) {
      promCateg5 = parseFloat(respuestaServ[4].promedioPorCategoria5);
    } else {
      cant -= 1;
      promCateg5 = 0.00;
    }

    if (respuestaServ[5] !== undefined) {
      promCateg6 = parseFloat(respuestaServ[5].promedioPorCategoria6);
    } else {
      cant -= 1;
      promCateg6 = 0.00;
    }

    if (respuestaServ[6] !== undefined) {
      promCateg7 = parseFloat(respuestaServ[6].promedioPorCategoria7);
    } else {
      cant -= 1;
      promCateg7 = 0.00;
    }

    PromedioGeneral = promCateg1 + promCateg2 + promCateg3 + promCateg4;
    PromedioGeneral += promCateg5 + promCateg6 + promCateg7;

    if (cant <= 0) {
      PromedioGeneral = 0.00;
    } else {
      PromedioGeneral /= cant;
    }

    $('#categ1').html(promCateg1.toFixed(2));
    $('#categ2').html(promCateg2.toFixed(2));
    $('#categ3').html(promCateg3.toFixed(2));
    $('#categ4').html(promCateg4.toFixed(2));
    $('#categ5').html(promCateg5.toFixed(2));
    $('#categ6').html(promCateg6.toFixed(2));
    $('#categ7').html(promCateg7.toFixed(2));

    $('#promedioFinal').html(PromedioGeneral.toFixed(2));
  }

});