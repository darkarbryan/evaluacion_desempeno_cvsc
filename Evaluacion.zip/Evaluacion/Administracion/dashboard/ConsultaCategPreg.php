<?php
	
	include_once '../../ConfigDB/config.php';

	/* SECCION PARA CARGAR LOS DATOS DE CATGORIAS EN EL FORMULARIO DE CREAR PREGUNTA */

	$ArrayCategorias = array();	
	$ArrayCategoriasId = array();
	$ConsultaCategoriasSQL = "SELECT * FROM categoria ORDER BY id";
	$pos=1;

	$ejecucion = mysqli_query($conexion,$ConsultaCategoriasSQL);

	while($Categorias=mysqli_fetch_array($ejecucion)){		

		$ArrayCategorias[$pos] = $Categorias['nombre'];
		$ArrayCategoriasId[$pos] = $Categorias['id'];
		$pos++;
	}

	/* SECCION PARA CARGAR LOS DATOS DE PREGUNTAS EN EL FORMULARIO DE EVALUACION */

	$ArrayPreguntas = array();
	$ArrayPreguntasId = array();
	$ArrayPreguntasCategoria = array();
	$consultaPreguntas = "SELECT * FROM pregunta ORDER BY orden,id";
	$pos2=1;

	$ejecucion2 = mysqli_query($conexion,$consultaPreguntas);

	while($Categorias2 = mysqli_fetch_array($ejecucion2)){
		$ArrayPreguntas[$pos2] = $Categorias2['pregunta'];
		$ArrayPreguntasId[$pos2] = $Categorias2['id'];
		$ArrayPreguntasCategoria[$pos2] = $Categorias2['categoria']; 
		$pos2++;		
	}

?>