<?php
header("Content-Type: text/html;charset=utf-8");	
date_default_timezone_set('America/Bogota');	

include_once '../../ConfigDB/config.php';

if( isset($_POST['opc']) ){

	$opcionConsulta = (int)$_POST['opc'];
	$anioActual = 2021;//date('Y');

	switch ($opcionConsulta) {

		case 1:

		$queryUsuariosEvaluadores = "SELECT terv_codigo, terc_nombre, carc_nombre, ubic_nombre FROM datosPersonal2, usuario WHERE terv_codigo=identificacion; ";

		$ejecucion = mysqli_query($conexion, $queryUsuariosEvaluadores);

		if(!$ejecucion){

			http_response_code(406);
			die(print_r(json_encode("Error al realizar la consulta EVALUADORES:".$conexion->error)));
		}

		$json = array();
		while($fila = mysqli_fetch_array($ejecucion)){
			$json[] = array(
				'identificacion'=>$fila['terv_codigo'],
				'nombre'=>$fila['terc_nombre'],
				'cargo'=>$fila['carc_nombre'],
				'ubicacion'=>$fila['ubic_nombre']
			);	
		}	

		http_response_code(201);

		//conversion del array json a JSON String
		$jsonCadena = json_encode($json); 
		echo $jsonCadena;			

		break;
		
		case 2:

		$queryUsuariosEvaluados = "SELECT terv_codigo, terc_nombre, carc_nombre, ubic_nombre, periodo_evaluacion FROM datosPersonal2, evaluacion WHERE terv_codigo=id_evaluado GROUP BY id_evaluado; ";

		$ejecucion2 = mysqli_query($conexion, $queryUsuariosEvaluados);

		if(!$ejecucion2){

			http_response_code(406);
			die(print_r(json_encode("Error al realizar la consulta EVALUADOS: ".$conexion->error)));
		}

		$json2 = array();
		while($fila = mysqli_fetch_array($ejecucion2)){

			$json2[] = array(				
				'identificacion'=>$fila['terv_codigo'],
				'nombre'=>$fila['terc_nombre'],
				'cargo'=>$fila['carc_nombre'],
				'ubicacion'=>$fila['ubic_nombre'],
				'periodo'=>$fila['periodo_evaluacion']
			);
		}		

		http_response_code(201);

		//conversion del array json a JSON String
		$jsonCadena2 = json_encode($json2); 
		echo $jsonCadena2;

		break;	

		case 3:

		$idEvaluado = $_POST['idEvaluado'];

		$queryResultadosEvaluacion = "SELECT id_evaluador, pregunta.id AS pregunta_id, pregunta AS nombre_pregunta, valor AS puntuacion FROM pregunta, evaluacion, evaluacion_detalle WHERE id_evaluado=$idEvaluado AND evaluacion.id=id_examen AND id_pregunta=pregunta.id; ";

		$queryDatosEvaluacion = "SELECT terv_codigo AS idEvaluador, terc_nombre AS nomEvaluador, carc_nombre AS cargoEvaluador, (select terv_codigo FROM datosPersonal2 WHERE terv_codigo=evaluacion.id_evaluado) AS idEvaluado,	(SELECT terc_nombre FROM datosPersonal2 WHERE terv_codigo=evaluacion.id_evaluado) AS nombreEvaluado, (SELECT carc_nombre FROM datosPersonal2 WHERE terv_codigo=evaluacion.id_evaluado) AS cargoEvaluado, (SELECT terf_ingreso FROM datosPersonal2 WHERE terv_codigo=evaluacion.id_evaluado ) AS fechaIngresoEvaluado, evaluacion.fecha_evaluacion AS fechaEvaluacion FROM datosPersonal2, evaluacion, evaluacion_detalle WHERE id_evaluado=$idEvaluado AND evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluador=datosPersonal2.terv_codigo GROUP BY id_evaluador; ";	

		$ejecucion3 = mysqli_query($conexion, $queryResultadosEvaluacion);
		$ejecucion3_1 = mysqli_query($conexion, $queryDatosEvaluacion);	

		if(!$ejecucion3 || !$ejecucion3_1){

			http_response_code(406);
			die(print_r(json_encode("Error al realizar la consulta EVALUACION: ".$conexion->error)));
		}	

		$json3 = array();		
		while($fila = mysqli_fetch_array($ejecucion3_1)){
			
			$json3[] = array(

				'idEvaluador'=>$fila['idEvaluador'],
				'nombreEvaluador'=>$fila['nomEvaluador'],
				'cargoEvaluador'=>$fila['cargoEvaluador'],
				'idEvaluado'=>$fila['idEvaluado'],
				'nombreEvaluado'=>$fila['nombreEvaluado'],
				'cargoEvaluado'=>$fila['cargoEvaluado'],
				'fechaIngresoEvaluado'=>$fila['fechaIngresoEvaluado'],
				'fechaEvaluacion'=>$fila['fechaEvaluacion']
				/*'fechaIngresoEvaluado'=>date_create_from_format('d-m-y', $fila['fechaIngresoEvaluado'])->format('Y-m-d'),*/
				
			);

			while($fila2 = mysqli_fetch_array($ejecucion3)){			

				if($fila['idEvaluador'] == $fila2['id_evaluador']){

					$json3[] = array(
						'idEvaluadorExamen'=>$fila2['id_evaluador'],
						'nombrePregunta'=>$fila2['nombre_pregunta'],
						'puntuacion'=>$fila2['puntuacion']
					);
				}
			}

			//se setea la variable y se vueve a consultar la informacion a la DB
			$ejecucion3 = null;
			$ejecucion3 = mysqli_query($conexion, $queryResultadosEvaluacion);	

		}
			
		http_response_code(201);	

		//conversion del array json a JSON String
		$jsonCadena3 = json_encode($json3); 
		echo $jsonCadena3;

		break;

		case 4:

		$queryCantidad_realizada_faltante="SELECT count(*) as cantidadRealizada, (SELECT count(*) FROM datosPersonal2 WHERE areaCargo!='ADMINISTRATIVOS') as cantidadTotal FROM evaluacion WHERE periodo_evaluacion=".$anioActual."; ";

		$ejecucion4 = mysqli_query($conexion, $queryCantidad_realizada_faltante);

		if(!$ejecucion4){

			http_response_code(406);
			die(print_r(json_encode("Error al realizar la consulta : ".$conexion->error)));
		}			

		$json4 = array();
		while($fila = mysqli_fetch_array($ejecucion4)){

			$json4[] = array(

				'cantidadRealizada'=>$fila['cantidadRealizada'],
				'cantidadTotal'=>$fila['cantidadTotal']

			);

		}

		http_response_code(201);

		//conversion del array json a JSON String
		$jsonCadena4 = json_encode($json4); 
		echo $jsonCadena4;

		break;

		case 5:

		$queryCantidadVigilantesRealizados = "SELECT COUNT(*) AS cantVigilantes FROM evaluacion, evaluacion_detalle, pregunta, categoria WHERE evaluacion.id=evaluacion_detalle.id_examen AND id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND pregunta.observacion='VIGILANTE' AND evaluacion.periodo_evaluacion=".$anioActual."; ";

		$queryCantidadSupervisoresRealizados = "SELECT COUNT(*) AS cantSupervisores FROM evaluacion, evaluacion_detalle, pregunta, categoria WHERE evaluacion.id=evaluacion_detalle.id_examen AND id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND pregunta.observacion='SUPERVISORES' AND evaluacion.periodo_evaluacion=".$anioActual."; ";

		$queryCantidadOmtRealizados = "SELECT COUNT(*) AS cantOmt FROM evaluacion, evaluacion_detalle, pregunta, categoria WHERE evaluacion.id=evaluacion_detalle.id_examen AND id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND pregunta.observacion='OMT' AND evaluacion.periodo_evaluacion=".$anioActual."; ";

		$queryCantidadEscoltasRealizados = "SELECT COUNT(*) AS cantEscoltas FROM evaluacion, evaluacion_detalle, pregunta, categoria WHERE evaluacion.id=evaluacion_detalle.id_examen AND id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND pregunta.observacion='ESCOLTAS' AND evaluacion.periodo_evaluacion=".$anioActual."; ";			

		$queryCantidadAdministrativosRealizados = "SELECT COUNT(*) AS cantAdministrativos FROM evaluacion, evaluacion_detalle, pregunta, categoria WHERE evaluacion.id=evaluacion_detalle.id_examen AND id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND pregunta.observacion='ADMINISTRATIVO' AND evaluacion.periodo_evaluacion=".$anioActual."; ";

		$ejecucion5_1 = mysqli_query($conexion, $queryCantidadVigilantesRealizados);

		$ejecucion5_2 = mysqli_query($conexion, $queryCantidadSupervisoresRealizados);

		$ejecucion5_3 = mysqli_query($conexion, $queryCantidadOmtRealizados);

		$ejecucion5_4 = mysqli_query($conexion, $queryCantidadEscoltasRealizados);

		$ejecucion5_5 = mysqli_query($conexion, $queryCantidadAdministrativosRealizados);

		if(!$ejecucion5_1 || !$ejecucion5_2 || !$ejecucion5_3 || !$ejecucion5_4 || !$ejecucion5_5){

			http_response_code(406);
			die(print_r(json_encode("Error al realizar consultas de estadisticas de pie : ".$conexion->error)));

		}

		$json5 = array();

		$fila1 = mysqli_fetch_array($ejecucion5_1);
		$fila2 = mysqli_fetch_array($ejecucion5_2);
		$fila3 = mysqli_fetch_array($ejecucion5_3);
		$fila4 = mysqli_fetch_array($ejecucion5_4);
		$fila5 = mysqli_fetch_array($ejecucion5_5);

		$json5 = array(

			'cantidadVigilantes'=>$fila1['cantVigilantes'],
			'cantidadSupervisores'=>$fila2['cantSupervisores'],
			'cantidadOmt'=>$fila3['cantOmt'],
			'cantidadEscoltas'=>$fila4['cantEscoltas'],
			'cantidadAdministrativos'=>$fila5['cantAdministrativos']

		);
		
		http_response_code(201);

		//conversion del array json a JSON String
		$jsonCadena5 = json_encode($json5); 
		echo $jsonCadena5;

		break;

		case 6:

			$queryPromedioCategorias = "SELECT categoria.nombre AS nombreCategoria, COUNT(*) AS cantidadRegistros, AVG(evaluacion_detalle.valor) AS sumatoriaPuntuacionCategorias FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE evaluacion_detalle.id_examen=evaluacion.id AND evaluacion_detalle.id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND evaluacion.periodo_evaluacion=".$anioActual." AND pregunta.observacion!='ADMINISTRATIVO' GROUP BY categoria.id; ";	

			$ejecucion6 = mysqli_query($conexion, $queryPromedioCategorias);

			if(!$ejecucion6){

				http_response_code(406);	
				die(print_r(json_encode("Error al realizar consultas de categorias de evaluacion : ".$conexion->error)));

			}	

			$json6 = array();
			$cont=1;

			while($fila = mysqli_fetch_array($ejecucion6)){

				$json6[] = array(
					'promedioPorCategoria'.$cont=>$fila['sumatoriaPuntuacionCategorias']			
				);
				$cont++;
			}			

			http_response_code(201);

			//conversion del array json a JSON String
			$jsonCadena6 = json_encode($json6); 
			echo $jsonCadena6;

		break;

		case 7:

			$queryPromedioAreasCargo = "SELECT pregunta.observacion AS areaCargo, COUNT(*) AS cantidadRegistros, AVG(evaluacion_detalle.valor) AS promedioAreaCargo FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE evaluacion_detalle.id_examen=evaluacion.id AND evaluacion_detalle.id_pregunta=pregunta.id AND pregunta.categoria=categoria.id AND evaluacion.periodo_evaluacion=".$anioActual." AND pregunta.observacion!='ADMINISTRATIVO' GROUP BY pregunta.observacion  ORDER BY pregunta.observacion desc; " ;

			$ejecucion7 = mysqli_query($conexion, $queryPromedioAreasCargo);

			if(!$ejecucion7){
			
				http_response_code(406);
				die(print_r(json_encode("Error al realizar consultas de categorias de evaluacion : ".$conexion->error)));

			}

			$json7 = array();

			while($fila = mysqli_fetch_array($ejecucion7)){

				$json7[] = array(
					'areaCargo'=>$fila['areaCargo'],
					'promedioArea'=>$fila['promedioAreaCargo']			
				);
				
			}			

			http_response_code(201);

			//conversion del array json a JSON String
			$jsonCadena7 = json_encode($json7); 
			echo $jsonCadena7;

		break;

		case 8:

		require_once "../../PHP/PHPExcel-1.8/Classes/PHPExcel.php";

		set_time_limit(900); //15 minutos de ejecucion como maximo del script en segundos

		$queryResultadosGeneralEvaluacion = "SELECT evaluacion.id AS id_evaluacion, datosPersonal2.terv_codigo AS id_evaluado, datosPersonal2.terc_nombre AS nombre_evaluado, STR_TO_DATE(datosPersonal2.terf_ingreso, '%Y-%m-%d') AS fechaingreso_evaluado, datosPersonal2.carc_nombre AS cargo, datosPersonal2.ubic_nombre AS ciudad, datosPersonal2.areaCargo AS area_cargo, STR_TO_DATE(evaluacion.fecha_evaluacion, '%Y-%m-%d') AS fecha_evaluacion, evaluacion.id_evaluador AS id_evaluador, usuario.nombre_completo AS nombre_evaluador,    (SELECT ROUND(AVG(evaluacion_detalle.valor), 2) FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=1) AS relaciones_interpersonales, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2)	FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=2) AS comunicacion, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2)	FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=3) AS actitud_servicio, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2)	FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=4) AS productividad, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2) FROM categoria, pregunta, evaluacion, evaluacion_detalle	WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=5) AS solucion_conflictos, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2) FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=6) AS calidad_compromiso, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2)	FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=7) AS seguridad_salud, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2) FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND	evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=8) AS orientacion_resultados, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2)	FROM categoria, pregunta, evaluacion, evaluacion_detalle WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=9) AS conocimientos_seguridad, (SELECT ROUND(AVG(evaluacion_detalle.valor), 2) FROM categoria, pregunta, evaluacion, evaluacion_detalle	WHERE categoria.id=pregunta.categoria AND evaluacion_detalle.id_pregunta=pregunta.id AND id_evaluacion=evaluacion.id AND evaluacion.id=evaluacion_detalle.id_examen AND evaluacion.id_evaluado=datosPersonal2.terv_codigo AND categoria.id=10) AS seguridad_salud_administrativos FROM datosPersonal2, evaluacion, usuario WHERE datosPersonal2.terv_codigo=cast(evaluacion.id_evaluado as char) AND evaluacion.id_evaluador=usuario.identificacion AND evaluacion.periodo_evaluacion=".$anioActual."; ";	

		$ejecucion8 = mysqli_query($conexion, $queryResultadosGeneralEvaluacion);

		if(!$ejecucion8){

			http_response_code(502);
			die(print_r(json_encode("Error al realizar la consulta : ".$conexion->error)));
		}	
		
		header('Content-Type: application/vnd.ms-Excel');
		header('Content-Disposition: attachment;filename="Resultados evaluacion de desempeño. Periodo ['.$anioActual.'].xlsx"');
		header('Cache-Control: max-age=0');

 		$objPHPExcel = new PHPExcel(); // Se crea el objeto PHPExcel

 		// Se asignan las propiedades del libro
		$objPHPExcel->getProperties()->setCreator("Colviseg del caribe")
    	->setLastModifiedBy("Aprendiz IT")
    	->setTitle("Reporte general de evaluacion de desempeño Periodo[".$anioActual."]") 
    	->setSubject("Evaluacion de desempeño Periodo [".$anioActual."]")
		->setDescription("Reporte de evaluacion de desempeño personal operativo y administrativo")
    	->setKeywords("reporte evaluacion desempeño")
    	->setCategory("Reporte excel");

    	$tituloReporte = 'Reporte de evaluacion de desempeño para el periodo ['.$anioActual.']';
    	$titulosColumnas = array('ID Evaluacion', 'ID Evaluado', 'Nombre evaluado', 'Fecha ingreso evaluado', 'Cargo evaluado', 'Ciudad', 'Area del cargo', 'Fecha de evaluacion', 'ID Evaluador', 'Nombre evaluador', 'Relaciones interpersonales', 'Comunicacion', 'Actitud de servicio', 'Productividad', 'Solucion de conflictos', 'Calidad de compromiso', 'Seguridad y salud en el trabajo', 'Orientacion de resultados', 'Conocimientos de seguridad', 'Seguridad y salud (Administrativos)', 'Promedio final');
			
    	// Se asigna el nombre a la hoja
    	$objPHPExcel->setActiveSheetIndex(0);
		$objPHPExcel->getActiveSheet()->setTitle('Resultados '.$anioActual.'');    	
  
		// Se agregan los titulos del reporte
		$objPHPExcel->setActiveSheetIndex(0)
    		->setCellValue('A1',$tituloReporte)    		
    		->setCellValue('A3',  $titulosColumnas[0])  
    		->setCellValue('B3',  $titulosColumnas[1])
    		->setCellValue('C3',  $titulosColumnas[2])
    		->setCellValue('D3',  $titulosColumnas[3])
    		->setCellValue('E3',  $titulosColumnas[4])
    		->setCellValue('F3',  $titulosColumnas[5])
    		->setCellValue('G3',  $titulosColumnas[6])
    		->setCellValue('H3',  $titulosColumnas[7])
    		->setCellValue('I3',  $titulosColumnas[8])
    		->setCellValue('J3',  $titulosColumnas[9])
    		->setCellValue('K3',  $titulosColumnas[10])
    		->setCellValue('L3',  $titulosColumnas[11])
    		->setCellValue('M3',  $titulosColumnas[12])
    		->setCellValue('N3',  $titulosColumnas[13])
    		->setCellValue('O3',  $titulosColumnas[14])
    		->setCellValue('P3',  $titulosColumnas[15])
    		->setCellValue('Q3',  $titulosColumnas[16])
    		->setCellValue('R3',  $titulosColumnas[17])
    		->setCellValue('S3',  $titulosColumnas[18])
    		->setCellValue('T3',  $titulosColumnas[19])
    		->setCellValue('U3',  $titulosColumnas[20]);   		

			$headerStyle = array(
				'fill' => array(
				'type' => PHPExcel_Style_Fill::FILL_SOLID,
				'color' => array('rgb'=>'4F81BD'),
			),
				'font' => array(
				'bold' => true,
				'color' => array('rgb'=>'FFFFFF')
			)
			);


			#esta linea aplica un estilo al fondo, yo la utilizo para los titulos de las columnas.
			$objPHPExcel->getActiveSheet()->getStyle('A3:U3')->applyFromArray($headerStyle);
		

		$i = 4; //pocision de la fila en excel donde se empezara a escribir.
		$suma; //variable para acumular la puntuacion de cada categoria.
		$cantidadCategorias = 7; 
		//hay 7 categorias, sea para administrativos o para el resto de areas de cargo (Vigilantes, OMT, Escoltas, Supervisores)

		while($fila = mysqli_fetch_array($ejecucion8)){

			$suma = $fila['relaciones_interpersonales']+$fila['comunicacion']+$fila['actitud_servicio']+$fila['productividad']+$fila['solucion_conflictos']+$fila['calidad_compromiso']+$fila['seguridad_salud']+$fila['orientacion_resultados']+$fila['conocimientos_seguridad']+$fila['seguridad_salud_administrativos'];
			
			$resultado = $suma/$cantidadCategorias;
			$promedio = number_format($resultado, 2);

			$objPHPExcel->getActiveSheet()
         	->setCellValue('A'.$i, $fila['id_evaluacion'])
         	->setCellValue('B'.$i, $fila['id_evaluado'])
         	->setCellValue('C'.$i, $fila['nombre_evaluado'])
         	->setCellValue('D'.$i, $fila['fechaingreso_evaluado'])
         	->setCellValue('E'.$i, $fila['cargo'])
         	->setCellValue('F'.$i, $fila['ciudad'])
         	->setCellValue('G'.$i, $fila['area_cargo'])
         	->setCellValue('H'.$i, $fila['fecha_evaluacion'])
         	->setCellValue('I'.$i, $fila['id_evaluador'])
         	->setCellValue('J'.$i, $fila['nombre_evaluador'])
         	->setCellValue('K'.$i, $fila['relaciones_interpersonales'])
         	->setCellValue('L'.$i, $fila['comunicacion'])
         	->setCellValue('M'.$i, $fila['actitud_servicio'])
         	->setCellValue('N'.$i, $fila['productividad'])
         	->setCellValue('O'.$i, $fila['solucion_conflictos'])
         	->setCellValue('P'.$i, $fila['calidad_compromiso'])
         	->setCellValue('Q'.$i, $fila['seguridad_salud'])
         	->setCellValue('R'.$i, $fila['orientacion_resultados'])
         	->setCellValue('S'.$i, $fila['conocimientos_seguridad'])         	
         	->setCellValue('T'.$i, $fila['seguridad_salud_administrativos'])
         	->setCellValueExplicit('U'.$i, $promedio); //setCellValueExplicit
         	$i++;	
         	$suma = 0; $resultado = 0;
		 
		}		

			#Estas lineas te permite autodimencionar las columnas para que se vean completas.
		    //$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('K')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('L')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('M')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('N')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('O')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('P')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('R')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('S')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('T')->setAutoSize(true);
		    $objPHPExcel->getActiveSheet()->getColumnDimension('U')->setAutoSize(true);

		$objPHPExcel->setActiveSheetIndex(0);		

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');

		#Esto es para que se genere el excel al ingresar al script, podes definir una ruta y directamente te genera el excel y lo guarda en la ruta que definas, siempre y cuando tenga los permisos para escribir en el servidor.

		http_response_code(201);   

		ob_end_clean();
		$objWriter->setPreCalculateFormulas(true);
		$objWriter->save('php://output');
		exit;	

		//para cerrar la pestaña abierta al finalizar
		echo "<script languaje='javascript' type='text/javascript'>window.close();</script>";	 			

		break;

		default:

			http_response_code(406);
			echo(json_encode("Opcion enviada no existente o no valida."));

		break;

	}

	mysqli_close($conexion);

}else{

	http_response_code(401);
	echo(json_encode("Ingreso no permitido"));

}

?>