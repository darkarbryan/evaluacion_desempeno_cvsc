<?php
	include_once "../ConfigDB/config.php";
	
	ob_start();
	session_name('ingreso_usuario');
	session_start();
	session_unset();
	session_destroy();

	mysqli_close($conexion);	
	echo '<script>window.location.href="../index.php";</script>';
?>