<!DOCTYPE html>
<html>
<head>
	<title>Ingresando...</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>	
</head>
<body>
	<?php
	include_once '../ConfigDB/config.php';

	//verificacion de que se esta ingresando desde el log in
	if (isset($_POST['submitIngreso'])) {

		ob_start();
		session_name('ingreso_usuario');
		session_start();
		
		$usr = (int)$_POST['usuario'];
		$pss = $_POST['clave'];	

		$consultaIngreso = "SELECT COUNT(*) AS contar FROM usuario WHERE identificacion=$usr AND contrasena='$pss' AND activo=1";

		$consultaNombre = "SELECT nombre_completo, rol_evaluacion FROM usuario WHERE identificacion=$usr ";

		try{

			$resultIngreso = mysqli_query($conexion,$consultaIngreso);
			$resultNombre = mysqli_query($conexion,$consultaNombre);

			$arrayIngreso = mysqli_fetch_array($resultIngreso);
			$arrayNombre = mysqli_fetch_array($resultNombre);

		}catch(Exception $e){
			?>
			
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: 'Error al tratar de iniciar sesion. Intente nuevamente.' }).then((result)=>{
						window.location.href="../index.php";
					});
			</script>

			<?php
		}	

		if($arrayIngreso['contar']>0){

			$_SESSION['id_usuario'] = $usr;
			$_SESSION['nom_usuario'] = $arrayNombre['nombre_completo'];
			$_SESSION['rol_usuario'] = $arrayNombre['rol_evaluacion'];
			$nombreUsuario = $_SESSION['nom_usuario'];		
			
			switch ($_SESSION['rol_usuario']) {

				case 1:
				?>

				<script>
					Swal.fire('Bienvenido!',<?php echo("'$nombreUsuario'"); ?>,'success').then((result)=>{						
							window.location.href="../Administracion/dashboard/menuAdministrador.php";
						});		
				</script>

				<?php				
				break;
				
				case 2:
				?>

				<script>
					Swal.fire('Bienvenido!',<?php echo("'$nombreUsuario'"); ?>,'success').then((result)=>{						
							window.location.href="../Evaluacion/Evaluacion.php";						
						});		
				</script>

				<?php
				break;
			}			
			
		}else{
			?>

			<!-- redireccion a login con javascript -->
			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: "Hubo un error al ingresar a la plataforma. Verifique que el usuario y la contraseña estén bien escritas o que el usuario este habilitado." }).then((result)=>{
						window.location.href="../index.php";
					});
			</script>		
			
			<?php
		}

		//si se accede a esta pagina sin haber pasado por index (log in), se redirige.
	}else{
		?>
		<script>window.location.href="../index.php";</script>
		<?php
	}
	?>
</body>
</html>