<?php
header("Content-Type: text/html;charset=utf-8");
include_once '../ConfigDB/config.php';

if( isset($_POST['rol_buscar']) ){

    $cargoBuscar = (string) $_POST['rol_buscar'];

    switch($cargoBuscar){

        case "1":
        $consultaCategorias = "SELECT * FROM categoria WHERE administrativo=1 ORDER BY id ASC";
        break;

        case "2":
        $consultaCategorias = "SELECT * FROM categoria WHERE vigilancia=1 ORDER BY id ASC";
        break;

        case "3":
        $consultaCategorias = "SELECT * FROM categoria WHERE supervision=1 ORDER BY id ASC";
        break;

        case "4":
        $consultaCategorias = "SELECT * FROM categoria WHERE omt=1 ORDER BY id ASC";
        break;

        case "5":
        $consultaCategorias = "SELECT * FROM categoria WHERE escolta=1 ORDER BY id  ASC";
        break;

    }

    $resultConsultaCategorias = mysqli_query($conexion,$consultaCategorias);

    if(!$resultConsultaCategorias){
      die(print_r("Error al obtener las categorias de evaluacion"));
  }

  $json2 =  array();

  while($fila = mysqli_fetch_array($resultConsultaCategorias)){
      $json2[] = array( 
        'id'=>$fila['id'],
        'nombre'=>$fila['nombre']
    );
  }
  mysqli_close($conexion);

  //conversion del array json a JSON String
  $json2Cadena = json_encode($json2);   
  echo $json2Cadena;

}else{

    //se trata de acceder sin haber iniciado seion. se redirige al index (log in).
    echo '<script>window.location.href="../index.php";</script>';

}
?>