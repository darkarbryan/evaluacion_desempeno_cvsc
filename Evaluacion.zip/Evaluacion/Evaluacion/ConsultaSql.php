<?php
header("Content-Type: text/html;charset=utf-8");
include '../ConfigDB/config.php';

$busqueda = $_POST['id_busqueda'];
$rol = $_POST['rol_buscar'];
$id_evaluador = $_POST['id_evaluador'];

if(!empty($busqueda)){
	
	switch($rol){
	    
	    case "1":
	        $cargo = 'ADMINISTRATIVOS';
	    break;
	    
	    case "2":
	        $cargo = 'VIGILANTES';
	    break;
	    
	    case "3":
	        $cargo = 'SUPERVISORES';
	    break;
	    
	    case "4":
	        $cargo = 'OMT';
	    break;
	    
	    case "5":
	        $cargo = 'ESCOLTAS';
	    break;
	    
	}
	
	$consulta ="SELECT terv_codigo, terc_nombre, terf_ingreso, carc_nombre, carn_codigo, ubic_nombre, ubin_codigo, areaCargo FROM datosPersonal2 WHERE areaCargo='$cargo' AND terv_codigo LIKE '%$busqueda%' ";
        
	$ejecucion = mysqli_query($conexion,$consulta);
    
	if(!$ejecucion){
		die(print_r("Error al realizar la consulta :".$conexion->error));
	}
    
	$json = array();
	while($fila = mysqli_fetch_array($ejecucion)){
		$json[] = array(
			'id' => $fila['terv_codigo'],
			'nombre' => $fila['terc_nombre'],						
			'fIngreso' => $fila['terf_ingreso'],
			'cargo' => $fila['carc_nombre'],			
			'sedeUbicacion' => $fila['ubic_nombre'] 			
		);
	}
    mysqli_close($conexion);    

    //ciclo para reemplazar las letras con acento y ñ
    //para que se pueda encodear en el JSON   

    for ($i=0; $i < sizeof($json); $i++) {
    //para reemplazar en el nombre del empleado 
    	$cadenaNombre = utf8_encode($json[$i]['nombre']);
    	$cadenaNombre = str_replace("ñ", "n", $cadenaNombre);
    	$cadenaNombre = str_replace("Á", "A", $cadenaNombre);
    	$cadenaNombre = str_replace("É", "E", $cadenaNombre);
    	$cadenaNombre = str_replace("Í", "I", $cadenaNombre);
    	$cadenaNombre = str_replace("Ó", "O", $cadenaNombre);
    	$cadenaNombre = str_replace("Ú", "U", $cadenaNombre);
    	$json[$i]['nombre'] = $cadenaNombre; 

	//para reemplazar en el cargo del empleado
    	$cadenaCargo = utf8_encode($json[$i]['cargo']);
    	$cadenaCargo = str_replace("ñ", "n", $cadenaCargo);
    	$cadenaCargo = str_replace("Á", "A", $cadenaCargo);
    	$cadenaCargo = str_replace("É", "E", $cadenaCargo);
    	$cadenaCargo = str_replace("Í", "I", $cadenaCargo);
    	$cadenaCargo = str_replace("Ó", "O", $cadenaCargo);
    	$cadenaCargo = str_replace("Ú", "U", $cadenaCargo);
    	$json[$i]['cargo'] = $cadenaCargo;
    }   

	//conversion del array json a JSON String
	$jsonCadena = json_encode($json); 
	echo $jsonCadena;
    
}


?>