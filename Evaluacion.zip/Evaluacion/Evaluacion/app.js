let respuestaServ;
let nom = "";
let ID = "";

let fechaIngreso = "";
let cargo = "";
let sede = "";

$(document).ready(function(){

//ocultar elementos de seleccion de evaluado
$('#tarjeta').hide();
$('#containerBoton').hide();
$('#botonesFinalFormulario').hide();

$('#id_buscar').keyup(function(){

	if($('#id_buscar').val()){		

		let id_busqueda = $('#id_buscar').val();
		let id_evaluador = $('#id_evaluador').val();
		let rol_buscar = $('select#tipoCargo').val();			

		$.ajax({
			url: 'ConsultaSql.php',
			type: 'POST',
			data: { id_busqueda, rol_buscar, id_evaluador },
			success: function(response){
				respuestaServ = JSON.parse(response);
	 			//plantilla para la informacion recibida.
	 			let template = `<option value=''>Seleccione una</option>`;	

	 			//recorriendo el arreglo de objetos
	 			respuestaServ.forEach(resp => {
	 				template += `<option value='${resp.id}'>${resp.nombre}</option>`;

	 			});
	 			
	 			//mostrar elementos de seleccion de evaluado a recuperar de la DB
	 			$('#infoId').html(template);	 			
	 			$('#tarjeta').show();
	 		}
	 	});
	}
});
});

function llenarInfo(){

	var valorSelect = document.getElementById("infoId").value;
	let tempFechaIngreso = "";	

	respuestaServ.forEach(resp => {		
		
		if(resp.id==valorSelect){

			nom = resp.nombre;
			ID = resp.id;
			fechaIngreso = resp.fIngreso;
			cargo = resp.cargo;
			sede = resp.sedeUbicacion;

			document.getElementById('etiquetaNombre').value = nom;
			document.getElementById('etiquetaId').value = ID;
			document.getElementById('etiquetaFechaIngreso').value = fechaIngreso;
			document.getElementById('etiquetaCargo').value = cargo;
			document.getElementById('etiquetaSedeUbica').value = sede;			
		}
	});
}

function mostrarPreguntas(){

    //borrar los input cada vez que se cambie el area de evaluacion
    document.getElementById('etiquetaNombre').value = "";
    document.getElementById('etiquetaId').value = "";
    document.getElementById('etiquetaFechaIngreso').value = "";
    document.getElementById('etiquetaCargo').value = "";
    document.getElementById('etiquetaSedeUbica').value = "";

    let rol_buscar = $('select#tipoCargo').val();
    let nombreArea = $('select#tipoCargo').find('option:selected').text();
    let templateCatePreg=`<h3 class="text-primary mt-3 mb-5" align="center">Evaluacion para ${nombreArea}</h3>`;
    let flag=true;	

	//consulta ajax para las categorias
	$.ajax({

		url: 'consultaCategoria.php',
		type: 'POST',
		data: { rol_buscar },
		success: function(response){

			respuestaServ2 = JSON.parse(response);

				//consulta ajax para las preguntas
				$.ajax({

					url: 'consultaPregunta.php',
					type: 'POST',
					data: { rol_buscar },
					success: function(response){				    
						
						respuestaServ3 = JSON.parse(response);

						for (var i = 0; i < respuestaServ2.length; i++) {		

							let nombreCategoria = respuestaServ2[i].nombre;
							let idCategoria = respuestaServ2[i].id;

					    //BLOQUE CABACERA DE LA CATEGORIA//
					    templateCatePreg += `<div class="container mt-3" align="center">`;
					    templateCatePreg += `<hr>`;
					    templateCatePreg += `<div class="row">`;
					    templateCatePreg += `<div class="col-md-12 col-sm-12 col-lg-12">`;
					    templateCatePreg += `<h4>${nombreCategoria}</h4>`;
					    templateCatePreg += `</div>`;
					    templateCatePreg += `</div>`;
					    templateCatePreg += `</div>`;
						//FIN BLOQUE CABECERA DE CATEGORIA	

						for (var j = 0; j < respuestaServ3.length; j++) {

							let nombrePregunta = respuestaServ3[j].nombre;
							let idPregunta = respuestaServ3[j].id;
							let idCategoriaPregunta = respuestaServ3[j].idCategoria;

							if(idCategoria==idCategoriaPregunta){

								templateCatePreg += `<div class="container mt-3">`;
								templateCatePreg += `<div class="row">`;
								templateCatePreg += `<div class="col-md-8 col-sm-6 col-lg-8 col-xs-6">`; 
								templateCatePreg += `<label>${nombrePregunta}</label>`;								
								templateCatePreg += `</div>`;
								templateCatePreg += `<div class="col-md-4 col-sm-6 col-lg-4 col-xs-6">`;
								templateCatePreg += `<select name="${idPregunta}" class="form-control" required >`;
								templateCatePreg += `<option value="">Seleccione una</option>`;
								templateCatePreg += `<option value="5">Excelente</option>`;
								templateCatePreg += `<option value="4">Alto</option>`;
								templateCatePreg += `<option value="3">Medio</option>`;
								templateCatePreg += `<option value="2">Basico</option>`;
								templateCatePreg += `<option value="1">Bajo</option>`;
								templateCatePreg += `</select>`;
								templateCatePreg += `</div>`;
								templateCatePreg += `</div>`;
								templateCatePreg += `</div>`;								
							}						    
							//AQUI VA LA LINEA D3 INSERCION .html	
							$('#contenedorPreguntas').html(templateCatePreg);							
						}
					}												
				}
			});		
			}
		});
	
	$('#botonesFinalFormulario').show();
}