<?php
header("Content-Type: text/html;charset=utf-8");
include_once '../ConfigDB/config.php';

if( isset($_POST['rol_buscar']) ){

	$cargo_buscar = (string) $_POST['rol_buscar'];

	//$idPreguntaCategoria = $_POST['idPreguntaCategoria'];

	switch($cargo_buscar){

		case "1":
		$cargo = "ADMINISTRATIVO";
		break;

		case "2":
		$cargo = "VIGILANTE";
		break;

		case "3":
		$cargo = "SUPERVISORES";
		break;

		case "4":
		$cargo = "OMT";
		break;

		case "5":
		$cargo = "ESCOLTAS";
		break;
	}

	$consultaPreguntas = "SELECT * FROM pregunta WHERE observacion='$cargo' ORDER BY id";

	$resultConsultaPreguntas = mysqli_query($conexion,$consultaPreguntas);

	if(!$resultConsultaPreguntas){
		die(print_r("Error al obtener las preguntas"));
	}

	$json3 = array();
	while($fila = mysqli_fetch_array($resultConsultaPreguntas)){
		$json3[] = array(
			'id'=>$fila['id'],
			'nombre'=>$fila['pregunta'],
			'idCategoria'=>$fila['categoria']
		);
	}
	mysqli_close($conexion);

	//conversion del array json a JSON String
	$json3Cadena = json_encode($json3);  	
	echo $json3Cadena;

}else{

	//se trata de acceder sin haber iniciado seion. se redirige al index (log in).
	echo '<script>window.location.href="../index.php";</script>';
}

?>