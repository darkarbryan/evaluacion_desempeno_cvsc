<!DOCTYPE html>
<html>
<head>
	<title>Registro de evaluacion.</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.16.3/dist/sweetalert2.all.min.js"></script>	
</head>
<body>
	<?php

	include_once '../OrigenDatos/ConsultaCategPreg.php';

	ob_start();
	session_name('ingreso_usuario');
	session_start();

	$id_login = $_SESSION['id_usuario'];
	$nombre_login = $_SESSION['nom_usuario'];
	$rol_login = $_SESSION['rol_usuario'];
	$fecha_actual = (string) date('Y-m-d');
	$periodo_actual = (string) date('Y');

//si se accede a esta pagina desde el formulario
	if( isset($_POST['submitEvaluacion']) ){

	//si recibe el valor del id del empleado en el select y no es nulo
		if( isset($_POST['infoId']) && $_POST['infoId']!="" && $_POST['etiquetaId']!=""){

			$idEvaluado = $_POST['etiquetaId'];
			$nombreEvaluado = $_POST['etiquetaNombre'];
			$fechaIngresoEvaluado = $_POST['etiquetaFechaIngreso'];
			$cargoEvaluado = $_POST['etiquetaCargo'];
			$sedeUbicacionEvaluado = $_POST['etiquetaSedeUbica'];
			$tipoEvaluacion = $_POST['tipoCargo'];

			switch ($cargoEvaluado) {
				case 'VIGILANTE':
				$cargo = 'VIG';
				break;

				case 'SUPERVISOR': 
				$cargo = 'SUP';
				break;

				case 'APRENDIZ':
				$cargo = 'APE';	

				default:
				$cargo = 'N/A';
				break;
			}		

			$evaluacionExistente = "SELECT COUNT(*) AS contar FROM evaluacion WHERE id_evaluador=$id_login AND id_evaluado=$idEvaluado AND periodo_evaluacion='$periodo_actual' ";	

			$resultExistente = mysqli_query($conexion,$evaluacionExistente);	
			$arrayExistente = mysqli_fetch_array($resultExistente);

			if($arrayExistente['contar']>0){
				?>

				<script>
					Swal.fire({icon: 'error',title: 'Oops...',text: 'Ya hay un registro para este periodo'}).then((result)=>{
						window.location.href="Evaluacion.php";
					});
				</script>

				<?php
			}else{

				$insertaEvaluacion = "INSERT INTO evaluacion (id_evaluador,id_evaluado,periodo_evaluacion,tipo_examen,fecha_evaluacion) values ($id_login,$idEvaluado,'$periodo_actual',$tipoEvaluacion,'$fecha_actual')";		

				if( mysqli_query($conexion,$insertaEvaluacion) ){	

					$idEvaluacionHecha = mysqli_insert_id($conexion);

					foreach ($ArrayCategorias as $key => $value) {
						foreach ($ArrayPreguntas as $key2 => $value2) {
							if($ArrayPreguntasCategoria[$key2]==$ArrayCategoriasId[$key]){

								if(array_key_exists($ArrayPreguntasId[$key2], $_POST)){

									$auxSelect = $_POST[$ArrayPreguntasId[$key2]];

									$insertaEvaluacionDetalle = "INSERT INTO evaluacion_detalle (id_pregunta,valor,id_examen) VALUES ($ArrayPreguntasId[$key2],$auxSelect,$idEvaluacionHecha)";

									mysqli_query($conexion,$insertaEvaluacionDetalle);
								}	
																
							}
						}
					}
					?>

					<script>
						Swal.fire('Todo en orden.','Evaluacion registrada exitosamente!','success').then((result)=>{							
							window.location.href="../Evaluacion/Evaluacion.php";							
						});		
					</script>

					<?php
				}else{
					?>

					<script>
						Swal.fire({icon: 'error',title: 'Oops...',text: 'Error al guardar los datos de evaluador y evaluado.' }).then((result)=>{
							window.location.href="../Evaluacion/Evaluacion.php";
						});
					</script>

					<?php
				}
			}

		}else{
			?>

			<script>
				Swal.fire({icon: 'error',title: 'Oops...',text: 'No se recibio identificacion del empleado a evaluar o fue nula.' }).then((result)=>{
					window.location.href="../Evaluacion/Evaluacion.php";
				});
			</script>

			<?php	
		}

	}else{
		?>
		<script>
			window.location.href="../Evaluacion/Evaluacion.php";
		</script>
		<?php	
	}

	mysqli_close($conexion);
	?>
</body>
</html>