<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
	<script src="app.js"></script>	

<title>Evaluacion de desempeño </title>
</head>
<body>
	<?php

	ob_start();
	session_name('ingreso_usuario');
	session_start();

	if( isset($_SESSION['id_usuario']) ){
		$id_login = $_SESSION['id_usuario'];
	}else{
		$id_login = "";
	}

	if( isset($_SESSION['nom_usuario']) ){
		$nombre_login = $_SESSION['nom_usuario'];
	}else{
		$nombre_login = "No existe";
	}

	if( isset($_SESSION['rol_usuario']) ){
		$rol_login = $_SESSION['rol_usuario'];
	}else{
		$rol_login = -1;
	}		
		
	$fecha_actual = date('Y-m-d');	

	if(isset($id_login) && $id_login!=""){
		?>

		<header>
			<div class="container" align="center">
				<div class="row align-items-center">
					<div class="col col-lg-3 col-sm-2">
						<img src="../Img/logo_colviseg.png"><br>				
					</div>
					<div class="col col-lg-6 col-sm-8 ">
						<h1 class="text-primary">Sistema de Gestión</h1>
						<h2 style="color:#1c1c1c">Evaluacion de Desempeño</h2>
					</div>
					<div class="col col-lg-3 col-sm-2">
						<img src="../Img/usuario_activo.png"><br>
						<label><?php echo $nombre_login ?></label><br>
						<label id="id_evaluador"><?php echo $id_login ?></label><br>
						<a href="../PHP/cierreSesion.php"><button type="button" class="btn btn-danger">Cerrar sesion</button></a>
					</div>
				</div>
			</div>
		</header>

		<div class="container pt-5" align="left">

			<section>
				<p>Los siguientes factores permiten evaluar si el colaborador cumplió las funciones y responsabilidades de su cargo y el nivel de cumplimiento de estas. Lea detenidamente cada criterio de evaluación y califique de manera objetiva el desempeño del colaborador, escogiendo la puntuación que se ajuste de acuerdo a la siguiente escala:
				</p>					
				<p style="text-align: center;"><strong>1 = Bajo 2 = Básico 3 = Medio 4 = Alto 5 = Excelente</strong></p>
			</section>

			<section>
				<p>
					<strong>NIVELES DE EVALUACIÓN</strong><br><br>									
					<strong>(5) EXCELENTE:</strong> Su desempeño supera las expectativas de la competencia evaluada, produce y genera resultados más allá de lo esperado. Siempre se destacan en su labor.									
					<br><strong>(4) ALTO:</strong> Su desempeño cumple siempre con las expectativas de la competencia evaluada. Tiene el desempeño esperado de una persona con la experiencia y conocimiento para desempeñar el cargo. 									
					<br><strong>(3) MEDIO:</strong> Su desempeño por lo general cumple con las expectativas de su cargo, hace bien su trabajo y muestra interés por mejorar la calidad de su trabajo. Necesita Plan de acompañamiento por parte de su jefe para reforzar sus competencias.

					<br><strong>(2) BÁSICO:</strong> Su desempeño se encuentra por debajo de lo esperado, por lo general hace su trabajo, pero no satisface todas las expectativas de la competencia evaluada. Necesita Plan de Mejoramiento y seguimiento en 3 meses.	

					<br><strong>(1) BAJO:</strong> No cumple con los requisitos de desempeño de la competencia evaluada. Requiere un Plan de acción inmediato por parte de su jefe y evaluación de seguimiento en tres meses.			
				</p>
			</section>

		</div>

		<form class="form-group" method="POST" action="registraEvaluacion.php" id="formEvaluacion">

			<div class="container mt-5 mb-5">
				<div class="row">					
					<div class="col-md-12 col-sm-12 col-lg-12">

						<div class="input-group mb-5">
							<span class="input-group-text text-primary">Seleccione el tipo de cargo de la persona a evaluar
							</span>
							<select class="form-control" required id="tipoCargo" name="tipoCargo" onchange="mostrarPreguntas()">
								<option value="">Seleccione uno</option>
								<option value="1">Administrativo</option>
								<option value="2">Vigilante</option>
								<option value="3">Supervisor</option>
								<option value="4">OMT (Operador de medios tecnologicos)</option>
								<option value="5">Escolta</option>
							</select>
						</div>

						<div class="input-group">
							<span class="input-group-text text-primary" >Buscar empleado</span>
							<input type="text" id="id_buscar" class="form-control" min="0" pattern="^[0-9]+" title="Solo numeros del 0 al 9" autosave="off" autocomplete="off" placeholder="Ingrese la identificacion del empleado a buscar">
						</div>

						<div class="card my-2" id="tarjeta">						
							<select onchange="llenarInfo()" id="infoId" name="infoId" class="form-control text-uppercase">	
							</select >
						</div>						

					</div>								
				</div>				

			</div>

			<div id="datosEvaluado" class="container mt-5 mb-5 card-footer">				
				<div class="row">
					<div class="col-md-7 col-sm-7 col-lg-7">
						
						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Fecha evaluacion</label>					
							</div>
							<div class="col-md-7">
								<label class="text-secondary h5"><?php echo($fecha_actual); ?></label>			
							</div>
						</div>					

						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Identificacion (Cedula)</label>
							</div>
							<div class="col-md-7">							
								<input id="etiquetaId" name="etiquetaId" type="text" required class="form-control text-secondary h5 text-uppercase" readonly style="background-color: #fff;">
							</div>
						</div>

						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Nombre empleado</label>
							</div>
							<div class="col-md-7">							
								<input id="etiquetaNombre" name="etiquetaNombre" type="text" required class="form-control text-secondary h5 text-uppercase" readonly style="background-color: #fff;">	
							</div>
						</div>					

					</div>

					<div class="col-md-5 col-sm-5 col-lg-5">

						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Fecha ingreso</label>								
							</div>
							<div class="col-md-7">
								<input id="etiquetaFechaIngreso" name="etiquetaFechaIngreso" type="text" required class="form-control text-secondary h5 text-uppercase" readonly style="background-color: #fff;"/>
							</div>
						</div>

						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Cargo</label>								
							</div>
							<div class="col-md-7">
								<input id="etiquetaCargo" name="etiquetaCargo" type="text" required class="form-control text-secondary h5 text-uppercase" readonly style="background-color: #fff;"/>
							</div>
						</div>

						<div class="row mt-2">
							<div class="col-md-5">
								<label class="text-primary h5">Sede ubicacion</label>								
							</div>
							<div class="col-md-7">
								<input id="etiquetaSedeUbica" name="etiquetaSedeUbica" type="text" required class="form-control text-secondary h5 text-uppercase" readonly style="background-color: #fff;"/>
							</div>
						</div>

					</div>

				</div>
			</div>	

			<div class="container mt-5 mb-5" id="contenedorPreguntas"></div>	
			
			<div id="botonesFinalFormulario">
				<div class="row pt-5 pb-5" align="center">
					<div class="col col-md-16 ">
						<input type="submit" id="submitEvaluacion" name="submitEvaluacion" value="Guardar evaluacion" class="btn btn-success">
						<input type="reset" name="Reestablecer" value="Reestablecer campos" class="btn btn-secondary">
					</div>									
				</div>
			</div>

		</form>			

		<!-- PIE DE PAGINA -->
		<footer class="card-footer text-muted mt-5" align="center" style="width: 100%;">
			<h3>Colviseg de caribe</h3>
		</footer>		
		
		<?php

	}else{
	//se trata de acceder sin haber iniciado seion. se redirige al index (log in).
	echo '<script>window.location.href="../index.php";</script>';
	}
	?>
</body>
</html>